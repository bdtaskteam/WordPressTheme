<?php if (!defined('FW')) die('Forbidden');
/**
 * @var string $uri Demo directory url
 */

$manifest = array();
$manifest['title'] = esc_html__('Appdown Demo', 'appdown');
$manifest['screenshot'] = get_template_directory_uri() . '/demo-content/appdown/screenshot.png';
$manifest['preview_link'] = 'http://soft6.bdtask.com/appdown/';