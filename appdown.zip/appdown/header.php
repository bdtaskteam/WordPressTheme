<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Appdown
 */

$main_logo  = defined('FW') ? fw_get_db_settings_option('main_logo') : '';
$main_logo  = isset($main_logo['url']) ? $main_logo['url'] : '';
if(defined('FW') & is_page()) {
    $is_titlebar = fw_get_db_post_option(get_the_ID(), 'is_page_title');
}else {
    $is_titlebar = 1;
}
$is_preloader       = defined('FW') ? fw_get_db_settings_option('is_preloader') : 1;
?>
<!doctype html>
<html <?php language_attributes(); ?> class="no-js">
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
    <?php endif; ?>
	    
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
 
     <!-- Preloader -->
<?php if($is_preloader==1) {?>
        <div class="preloader"></div> 
        <?php }?>
        <!--========== Header Area ==========-->
        <header class="header_part">
            <div class="container">
                <nav class="navbar header navbar-toggleable-md navbar-light">
                    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                        <?php
                        

                        if(!empty($main_logo)) {
                        ?>
                        <img src="<?php echo esc_url($main_logo); ?>" alt="Company Logo">
                        <?php
                         } else {
                                echo '<h2 class="h_header">'.get_bloginfo('name').'</h2>';
                        }
                        ?>
                    </a>
                    <div class="collapse navbar-collapse justify-content-end" id="navbarText">
    

                        <?php
            
                         wp_nav_menu( array(
                         'theme_location' => 'main_menu', // Defined when registering the menu
                         'menu_id'        => 'main_menu',
                         'container'      => false,
                         'depth'          => 2,
                         'menu_class'     => 'nav navbar-nav',
                         'walker'         => new bs4Navwalker(), // This controls the display of the Bootstrap Navbar
                         'fallback_cb'    => 'bs4Navwalker::fallback', // For menu fallback
                         'link_before' => '<span>',
                         'link_after' => '</span>',
                         ) );
 
                        ?>

                        <div class="navbar-text animated_search_box">                
                            <div class="search_icon">
                                <i class="fa fa-search"></i>
                            </div>
                            <div class="hidden_search_box">
                                <form action="<?php echo esc_url(home_url('/'));?>" method="get" class="search-form">
                                    <input type="search" class="form-control" placeholder="<?php echo esc_html__('Search ... ','appdown') ;?>" name='s'>
                                </form>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
        </header>
        <!--==========End Header Area ==========-->
    
        <?php  bdt_social_share();

      
        ?>
        <!--========== End Fixed Social Icon Area ==========-->
        
        <!--==========Page Header ==========-->
<?php

    if(is_home() & !is_single()) {
        if ($is_titlebar == 1) {
            bdt_pagetitlebar();
        }
    }
?>
 
        
    <!--==========End Page Header ==========-->
  


