<?php
/**
 * 
 * 
 *
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Appdown
 */

get_header(); 

$read_more = defined('FW') ? fw_get_db_settings_option('blog_read_more') : esc_html__('Read More','appdown');
$blog_excerpt = defined('FW') ? fw_get_db_settings_option('blog_excerpt') : 30;

?>

  <section class="appstore_area">
            <div class="container">
                <div class="row appstore_inner container_section">
                    <div class="col-md-4">
                        <!--=== sidebar =====-->
                        <div id="sidebar"> 
                           <?php get_sidebar(); ?>
                          
                        </div>
                    </div>
                    
                    <div class="col-md-8">
                        <div id="content">
                            <!--==== Apps Category ===-->
                            <div class="row m0 apps_category_part">
                                <div class="row m0 headline">
                                   <?php
                            the_archive_title('<h3 class="page-title">', '</h3>');
                            ?> 
      	                 
                                </div>
                                 
                                 <?php  
                                 if ( have_posts() ) :
	     						  while (have_posts()) : the_post();
                                    $app_version = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_version') : '';
                                      $app_companny= defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_companny') : '';
                                $upload_dgsdf   = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'upload_apps'): '';
                                   $upload_dgsdf  = isset($upload_dgsdf['url']) ? $upload_dgsdf ['url'] : '';
	     						  	?>
                                 <section id="posts">
                                <div class="row m0 apps_category wow fadeInDown post">

                                    <div class="col-lg-3 img_part">
                                       
                                        <?php the_post_thumbnail('bdt_150x156',array('class'=>'d-flex')); ?>
                                    </div>
                                    <div class="col-lg-9">
                                        <div class="row item_info">
                                            <a href="<?php the_permalink(); ?>" class="blog-title"><?php echo wp_trim_words(get_the_title(),6, ''); ?></a>
                                            <ol class="breadcrumb">
                                                <?php if(empty($app_companny)){?>
                                                <li class="breadcrumb-item"<?php echo esc_html($app_companny);?></li>
                                                 <?php } ?>
                                                <li class="breadcrumb-item"><?php echo esc_html('version :','appdown')?> <?php echo esc_html($app_version); ?></li>
                                            </ol>
                                            <p class="text-justify">
                                                  <?php echo wp_trim_words(get_the_content(),20, ''); ?> 
                                                  <span><a  href="<?php the_permalink(); ?>"><?php echo $read_more; ?></a> </span></p>
                                            <div class="item_dload">
                                                <div class="rating_area">
                                                    <div class="rate-container">
                                                      <?php bdt_avg_star_rating('post', $post->ID); ?>
                                                    </div>
                                                </div>
                                                <div class="free_btn">
                                                       <?php if(!empty($upload_dgsdf)){?>
                                                    <a href="<?php echo  esc_url($upload_dgsdf); ?>" class="nav-link  hover_style" download>
                                                        <span><?php echo esc_html('Free Download','appdown');?></span>
                                                        <i class="fa fa-download"></i>
                                                    </a>
                                                    <?php }?>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
				        <?php endwhile; endif;?>


                            </div>
                            
                              <!-- start pagination -->
                            <div class="row m0 pagination_part">
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination justify-content-center ">
                                       <div class="text-center">
                                   
                                    <?php 
                                        $pagination = get_the_posts_pagination(array(
                                            'mid_size'  => 2,
                                            'prev_text' => '<i class="fa fa-chevron-left"></i><span class="span_link">'.esc_html__('Previous', 'appdown').'</span>',
                                            'next_text' => '<span class="span_link_right">'.esc_html__('Next', 'appdown') .'</span><i class="fa fa-chevron-right"></i>',
                                            'screen_reader_text' => ' ',
                                        ) );
                                        echo $pagination;
                                    ?>
                                  

                                    </ul>
                                    </div>
               
                                </nav>
                            </div>
                            <!-- end pagination -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--========== End Appstore Area ==========-->


<?php

get_footer();
