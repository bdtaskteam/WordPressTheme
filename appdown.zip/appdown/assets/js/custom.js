
(function($){
    "use strict"; 
    
    // Hide Loading Box (Preloader)
    jQuery(window).on('load', function() {
       
        jQuery('.preloader').delay(500).fadeOut('slow');
        jQuery('body').delay(500).css({'overflow':'visible'});
    });
    
    // Sticky Menu
    jQuery(window).on('scroll', function() {
        if (jQuery(window).scrollTop() > 300) {
            jQuery('.header_part').addClass('menu_fixed');
        } else {
            jQuery('.header_part').removeClass('menu_fixed');
        }
    });
    
    // Hidden Search Box
    jQuery( window ).on( "load", function() {
        jQuery(".search_icon").on('click', function(){
            jQuery(".hidden_search_box").slideToggle("slow");
        });
    }); 
    
    // Owl Carousel
    jQuery('.owl-carousel').owlCarousel({
        stagePadding: 50,
        loop:true,
        items: 1,
        autoplay: true,
        autoplayTimeout: 4000,
        smartSpeed: 1000,
        margin: 10,
        dots: false,
        nav:true,
        navText:['<i class="fa fa-chevron-left"></i>','<i class="fa fa-chevron-right"></i>']
    })
    
    // Back to Top Js
    jQuery( window ).on( "load", function(){
        var offset = 300,
            offset_opacity = 1200,
            scroll_top_duration = 700,
            jQueryback_to_top = jQuery('.cd-top');
        
        jQuery(window).on('scroll', function(){
            ( jQuery(this).scrollTop() > offset ) ? jQueryback_to_top.addClass('cd-is-visible') : jQueryback_to_top.removeClass('cd-is-visible cd-fade-out');
            if( jQuery(this).scrollTop() > offset_opacity ) { 
                jQueryback_to_top.addClass('cd-fade-out');
            }
        });

        //smooth scroll to top
        jQueryback_to_top.on('click', function(event){
            event.preventDefault();
            jQuery('body,html').animate({
                scrollTop: 0 ,
                }, scroll_top_duration
            );
        });

    });
    
    // WOW JS
    new WOW().init();

})(jQuery);   