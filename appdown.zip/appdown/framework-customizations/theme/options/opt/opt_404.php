<?php

if (!defined('FW')) {
    die('Forbidden');
}
$options = array(
    '404' => array(
        'title' => esc_html__('404 Settings','appdown'),
        'type' => 'tab',
        'options' => array(
            'general-box' => array(
                'title' => esc_html__('404 Page Settings','appdown'),
                'type' => 'tab',
                'options' => array(
                    'four_image' => array(
                        'label'         => esc_html__('404 Image','appdown'),
                        'type'          => 'upload',
                        'value'         => '404',
                        'images_only'   => true,
                    ),
                    'four_heading'  => array(
                        'label'     => esc_html__('Heading','appdown'),
                        'type'      => 'text',
                        'value'     => '404',
                        'desc'      => esc_html__('404 heading text.','appdown')
                    ),
                    'four_subtitle' => array(
                        'label'     => esc_html__('Subtitle','appdown'),
                        'type'      => 'wp-editor',
                        'value'     => '<h4>The page you were looking for dosen’t exist.</h4>',
                        'desc'      => esc_html__('Enter 404 page subtitle text.','appdown'),
                        'reinit'    => true,
                        'size'      => 'small',
                        'editor_type' => false,
                    ),
                    'four_button_label' => array(
                        'label' => esc_html__('Button Label','appdown'),
                        'desc' => esc_html__('Enter button label','appdown'),
                        'type' => 'text',
                        'value' => 'Go To the home page'
                    ),
                    'four_button_link' => array(
                        'label' => esc_html__('Button Link','appdown'),
                        'desc' => esc_html__('Enter link URL related to the button','appdown'),
                        'type' => 'text',
                        'value' => '#'
                    )
                )
            ),
        )
    )
);
