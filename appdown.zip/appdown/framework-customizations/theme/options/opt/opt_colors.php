<?php

if (!defined('FW')) {
    die('Forbidden');
}
$options = array(
    'colors' => array(
        'title' => esc_html__('Color Style Settings', 'appdown'),
        'type' => 'tab',
        'options' => array(
            'color_scheme_tab' => array(
                'title' => esc_html__('Color Scheme', 'appdown'),
                'type' => 'tab',
                'options' => array(
                    'accent_color' => array(
                        'type'          => 'color-picker',
                        'label'         => esc_html__('Accent color', 'appdown'),
                        'desc'          => esc_html__('Change the main color scheme of the theme #f60d2b', 'appdown'),
                        'value'         => '#00bf9a',
                    ),  
                    'accent_colorvbncvbnvc' => array(
                        'type'          => 'color-picker',
                        'label'         => esc_html__('Hover  Bg-color', 'appdown'),
                        'desc'          => esc_html__('Change Hover Bg-color scheme of the theme #00bf9a', 'appdown'),
                        'value'         => '#00bf9a',
                    ),  

                    'accent_all_black' => array(
                        'type'          => 'color-picker',
                        'label'         => esc_html__('Accent Black color', 'appdown'),
                        'desc'          => esc_html__('Change All Black color scheme of the theme #000', 'appdown'),
                        'value'         => '#000',
                    ),   
                    'accent_all_white' => array(
                        'type'          => 'color-picker',
                        'label'         => esc_html__('All White  color', 'appdown'),
                        'desc'          => esc_html__('Change All White color scheme of the theme #fff', 'appdown'),
                        'value'         => '#fff',
                    ), 
                  
                )
            ),
            'footer_color_tab' => array(
                'title' => esc_html__('Footer Colors', 'appdown'),
                'type' => 'tab',
                'options' => array(
                    'footer_bg_color' => array(
                        'type'          => 'color-picker',
                        'label'         => esc_html__('Footer background color', 'appdown'),
                        'value'         => '#111',
                    ),
            
                )
            ),

            'header_color_tab' => array(
                'title' => esc_html__('Header background Color', 'appdown'),
                'type' => 'tab',
                'options' => array(
                    'header_color' => array(
                        'type'          => 'color-picker',
                        'label'         => esc_html__('Header background color', 'appdown'),
                        'value'         => '#fff',
                    )
                ),
            ),
        )
    )
);
