<?php

if (!defined('FW')) {
    die('Forbidden');
}

$options = array(

    // Pricing meta
    'page_meta'   => array(
        'title'     => esc_html__('Page Settings','appdown'),
        'type'      => 'tab',
        'options'   => array(
            'is_page_title' => array(
                'type'          => 'switch',
                'label'         => esc_html__('Show title-bar?','appdown'),
                'desc'          => esc_html__('Switch to no if want to hide the page title-bar.', 'appdown'),
                'value'         => true,
            ),
            'page_top_shortcodes' => array(
                'type'          => 'textarea',
                'label'         => esc_html__('Top Shortcodes Content','appdown'),
                'desc'          => esc_html__('The shortcode will be placed to the top of the page content.','appdown'),
            ),
        )
    ),

);
