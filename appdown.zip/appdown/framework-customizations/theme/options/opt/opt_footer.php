<?php

if (!defined('FW')) {
    die('Forbidden');
}
$options = array(
    'footer_opt' => array(
        'title' => esc_html__('Footer Options','appdown'),
        'type' => 'tab',
        'options' => array(
            'footer_config_tab' => array(
                'title' => esc_html__('Footer configurations','appdown'),
                'type' => 'tab',
                'options' => array(
                    'footer_bg' => array(
                        'type'          => 'color-picker',
                        'label'         => esc_html__('Background color','appdown'),
                        'desc'          => esc_html__('Footer widgets area background color', 'appdown'),
                        'value'         => '#242121'
                    ),
                    'copyright_text'  => array(
                        'type'          => 'textarea',
                        'label'         => esc_html__('Copyright text','appdown'),
                        'value'         => '<a class="nav-link" href="#">&copy;2017 Google Site</a>'
                    ),
                )
            ),
            'mailchimp_config_box' => array(
                'title' => esc_html__('Footer Top ','appdown'),
                'type' => 'tab',
                'options' => array(
                    'is_mc_form'  => array(
                        'type'          => 'switch',
                        'label'         => esc_html__('Show subscribe form?','appdown'),
                        'value'         => true
                    ),
                    'mc_form_title'  => array(
                        'type'          => 'text',
                        'label'         => esc_html__('Title','appdown'),
                        'value'         => 'YOUR CREATIVE BUSINESS'
                    ),
                    'mc_form_subtitle'  => array(
                        'type'          => 'text',
                        'label'         => esc_html__('Subtitle','appdown'),
                        'value'         => 'LINE GOES HERE'
                    ), 
                    'mc_form_imag'  => array(
                        'label'         => esc_html__('Subtitle','appdown'),
                        'type'          => 'upload',
                                    'images_only'   => true,
                    ),
                    'mc_level' => array(
                        'type'          => 'text',
                        'label'         => esc_html__('Button Level  text','appdown'),
                        'value'         => 'Buy Now'
                    ),

                     'mc_button_link' => array(
                        'type'          => 'text',
                        'label'         => esc_html__('Button Level  text','appdown'),
                        'value'         => '#'
                    ),
                 
                )
            ),
        )
    )
);
