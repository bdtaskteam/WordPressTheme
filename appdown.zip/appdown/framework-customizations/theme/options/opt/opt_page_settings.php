<?php

if (!defined('FW')) {
    die('Forbidden');
}
$options = array(
    'page_settings_opt' => array(
        'title' => esc_html__('Contact Page settings','appdown'),
        'type' => 'tab',
        'options' => array(

            // Contact page settings
            'contact_page_opt' => array(
                'title' => esc_html__('Contact Page','appdown'),
                'type' => 'tab',
                'options' => array(
                    
                    'cf7_title' => array(
                        'type'      => 'text',
                        'label'     => esc_html__('Contact form Title','appdown'),
                        'value'     => 'Get In Touch'
                    ),
                    'cf7_shortcode' => array(
                        'type'      => 'text',
                        'label'     => esc_html__('Contact form shortcode','appdown'),
                        'desc'      => esc_html__("Generate the contact form shortcode by Contact Form 7 plugin.",'appdown'),
                    ),
               
                    'contact_details' => array(
                        'type'  => 'wp-editor',
                        'label' => esc_html__(' Write Your Map Address','appdown'),
                        'size' => 'small', // small, large
                        'editor_height' => 200,
                         'value'   =>'1207 Mohammad pur Solimullah Road',
                        'wpautop' => true,
                        'editor_type' => false, // tinymce, html

                       
                    ),
       
                )
            ),


        )
    )
);
