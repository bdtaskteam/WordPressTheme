<?php

if (!defined('FW')) {
    die('Forbidden');
}
$options = array(
    'header' => array(
        'title' => esc_html__('Header Options','appdown'),
        'type' => 'tab',
        'options' => array(
             
          'is_preloader' => array(
                'type'          => 'switch',
                'label'         => esc_html__('Show preloader?','appdown'),
                'desc'          => esc_html__('Switch to no if want to hide the page title-bar.', 'appdown'),
                'value'         => true,
            ),

            'main_logo' => array(
                'type'          => 'upload',
                'label'         => esc_html__('Main Logo','appdown'),
                'images_only'   => true,
            ),
            'favicon'  => array(
                'type'          => 'upload',
                'label'         => esc_html__('Favicon icon','appdown'),
                'images_only'   => true,
            ),
           

      
        )
    )
);
