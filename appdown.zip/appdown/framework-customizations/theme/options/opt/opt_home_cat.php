<?php

if (!defined('FW')) {
    die('Forbidden');
}


$options = array(
    'home_page' => array(
        'title' => esc_html__(' Home Page Settings', 'appdown'),
        'type' => 'tab',
        'options' => array(
        
        'contact_page_opt' => array(
        'title' => esc_html__('Sideber Apps', 'appdown'),
        'type' => 'tab',
        'options' => array(
        'upload_theme_apps'  =>  array(
          'type'    => 'upload',
            'label'   => esc_html__('Upload Your App ', 'appdown'),
            'desc'    => esc_html__('doc , pdf , zip , apk, exc  , Upload This ', 'appdown'),
            'images_only' => false,
            'files_ext' => array( 'doc', 'pdf', 'zip','apk','exe' ),
        ), 

        'apps_version' => array(
            'type'      => 'text',
            'label'     => esc_html__('Version  Title', 'appdown'),
            'value'     => 'version'
            ), 

        'apps_short_note' => array(
            'type'      => 'text',
            'label'     => esc_html__(' App Short Note', 'appdown'),
            'value'     => 'App Short Note'
            ),   
        'apps_logo' => array(
            'type'      => 'upload',
            'label'     => esc_html__('Version logo', 'appdown'),
            'images_only'   => true,
            ),
    )
),

   // Category Position Home      
     'category_positions' => array(
        'title' => esc_html__('Set Category Positions', 'appdown'),
        'type' => 'tab',
        'options' => array(
          'cat' => array( 
            'type' => 'select', 
            'value' => 'choice-3', 
            'label' => __('Category Position One', 'appdown'), 
            'desc' => __('Set Your Position Where You Want To Show This.', 'appdown'), 
            'help' => __('Help tip', 'appdown'), 
            'choices' => wp_list_pluck( get_terms( 'category' ), 'name', 'slug' )
             ),


           'cats' => array( 
            'type' => 'select', 
            'value' => 'choice-3', 
            'label' => __('Category Position Two', 'appdown'), 
            'desc' => __('Set Your Position Where You Want To Show This.', 'appdown'), 
            'help' => __('Help tip', 'appdown'), 
            'choices' => wp_list_pluck( get_terms( 'category' ), 'name', 'slug' ) ),

           'cats_three' => array( 
            'type' => 'select', 
            'value' => 'choice-3', 
            'label' => __('Category Position Three', 'appdown'), 
            'desc' => __('Set Your Position Where You Want To Show This.', 'appdown'), 
            'help' => __('Help tip', 'appdown'), 
            'choices' => wp_list_pluck( get_terms( 'category' ), 'name', 'slug' ) ),   
            
            'cats_four' => array( 
            'type' => 'select', 
            'value' => 'choice-3', 
            'label' => __('Category Position Four', 'appdown'), 
            'desc' => __('Set Your Position Where You Want To Show This.', 'appdown'), 
            'help' => __('Help tip', 'appdown'), 
            'choices' => wp_list_pluck( get_terms( 'category' ), 'name', 'slug' ) ), 

            'cats_five' => array( 
            'type' => 'select', 
            'value' => 'choice-3', 
            'label' => __('Category Position Five', 'appdown'), 
            'desc' => __('Set Your Position Where You Want To Show This.', 'appdown'), 
            'help' => __('Help tip', 'appdown'), 
            'choices' => wp_list_pluck( get_terms( 'category' ), 'name', 'slug' ) ),

            'cats_six' => array( 
            'type' => 'select', 
            'value' => 'choice-3', 
            'label' => __('Category Position Six', 'appdown'), 
            'desc' => __('Set Your Position Where You Want To Show This.', 'appdown'), 
            'help' => __('Help tip', 'appdown'), 
            'choices' => wp_list_pluck( get_terms( 'category' ), 'name', 'slug' ) ),

)),






'category_positionsasdfadsf' => array(
        'title' => esc_html__('Home Banner', 'appdown'),
        'type' => 'tab',
        'options' => array(
          'banner_title' => array( 
             'type'    => 'text',
             
                'label'   => esc_html__('Home Banner Title ', 'appdown'),
                
             ),  
          'offer_title' => array( 
             'type'    => 'text',
                'value'   =>'Save 50%',
                'label'   => esc_html__('Offer Title ', 'appdown'),
             ),  
          'button_link' => array( 
             'type'    => 'text',
                'value'   =>'#',
                'label'   => esc_html__('Button Link  ', 'appdown'),
                
             ),  
          'banner_image' => array( 
             'type'    => 'upload',
              
                'label'   => esc_html__('Left Banner Images', 'appdown'),
                
             ),
'banner_right_title' => array( 
             'type'    => 'text',
                'value'   =>'Write Your Title',
                'label'   => esc_html__('Home Banner Right Title ','appdown'),
                
             ),  
          'offer_right_title' => array( 
             'type'    => 'text',
                'value'   =>'Save 50%',
                'label'   => esc_html__('Offer Right Title ','appdown'),
             ),  
          'button_right_link' => array( 
             'type'    => 'text',
                'value'   =>'#',
                'label'   => esc_html__('Button Right Link ','appdown'),
                
             ),  
          'banner_right_image' => array( 
             'type'    => 'upload',
                'value'   =>'#',
                'label'   => esc_html__('Upload Image ','appdown'),
                
             ),



      )),









        )
    )
);
