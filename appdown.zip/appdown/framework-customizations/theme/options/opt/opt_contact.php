<?php

if (!defined('FW')) {
    die('Forbidden');
}
$options = array(
    'contact_page_opt' => array(
            'title' => esc_html__('Contact page settings','appdown'),
            'type' => 'tab',
            'options' => array(
                'contact_header' => array(
                    'title' => esc_html__('Header settings','appdown'),
                    'type' => 'tab',
                    'options' => array(
                        'contact_header_boxes' => array(
                            'type'  => 'addable-box',
                            'label' => esc_html__('Header info boxes','appdown'),
                            'desc'  => esc_html__('Add header info boxes with icon','appdown'),
                            'box-options' => array(
                                'icon' => array( 'type' => 'icon', 'label' => esc_html__('Icon','appdown'), 'value' => 'fa fa-facebook-official' ),
                                'link' => array( 'type' => 'text', 'label' => esc_html__('Link','appdown'), 'value' => '#' ),
                                'text' => array( 'type' => 'text', 'label' => esc_html__('Text content','appdown'), 'value' => esc_html__('Facebook','appdown')),
                            ),
                            'template' => '{{- text }}', // box title
                            'box-controls' => array( // buttons next to (x) remove box button
                                'control-id' => '<small class="dashicons dashicons-share"></small>',
                            ),
                            'limit' => 0, // limit the number of boxes that can be added
                            'add-button-text' => esc_html__('Add box','appdown'),
                            'sortable' => true,
                        ),
                    ),
                ),

                'contact_form' => array(
                    'title' => esc_html__('Contact form','appdown'),
                    'type' => 'tab',
                    'options' => array(
                        'cf7_shortcode' => array(
                            'type'      => 'text',
                            'label'     => esc_html__('Contact form shortcode', 'appdown'),
                            'desc'      => esc_html__("Generate the contact form shortcode by Contact Form 7 plugin.",'appdown'),
                        ),
                        'cf7_submit_btn' => array(
                            'type'      => 'text',
                            'label'     => esc_html__('Submit button label','appdown'),
                            'value'     => 'Send'
                        ),
                    )
                ),

                'contact_map' => array(
                    'title' => esc_html__('Map settings', 'appdown'),
                    'type' => 'tab',
                    'options' => array(
                        'map_lat' => array(
                            'type'      => 'text',
                            'label'     => esc_html__('Latitude', 'appdown'),
                            'desc'      => wp_kses_post(__("Get latitude from <a href='http://www.mapcoordinates.net/en' target='_blank'>here</a>", 'appdown')),
                            'value'     => '23.8103968'
                        ),
                        'map_lng' => array(
                            'type'      => 'text',
                            'label'     => esc_html__('Longitude','appdown'),
                            'desc'      => wp_kses_post(__("Get Longitude from <a href='http://www.mapcoordinates.net/en' target='_blank'>here</a>",'appdown')),
                            'value'     => '90.41256666'
                        ),
                        'map_icon' => array(
                            'type'      => 'upload',
                            'label'     => esc_html__('Marker icon','appdown'),
                            'images_only' => true
                        ),
                    )
                ),
        )
    )
);
