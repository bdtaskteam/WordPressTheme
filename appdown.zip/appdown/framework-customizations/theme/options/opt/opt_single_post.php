<?php

if (!defined('FW')) {
    die('Forbidden');
}
$options = array(
    'single_post_opt' => array(
        'title' => esc_html__('Single post settings','appdown'),
        'type' => 'tab',
        'options' => array(
            'single_post_settings' => array(
                'title' => esc_html__('Single page config','appdown'),
                'type' => 'tab',
                'options' => array(
                    'post_share' => array(
                        'type'      => 'multi-picker',
                        'label'     => false,
                        'desc'      => false,
                        'picker'    => array(
                            'is_post_share'     => array(
                                'type'          => 'switch',
                                'label'         => esc_html__('Show share buttons','appdown'),
                                'desc'          => esc_html__('Would you like to keep social share button on post single page?','appdown'),
                                'left-choice'   => array(
                                    'value'     => 'yes',
                                    'label'     => esc_html__('Yes','appdown'),
                                ),
                                'right-choice'  => array(
                                    'value'     => 'no',
                                    'label'     => esc_html__('No','appdown'),
                                ),
                            ),
                        ),
                        'choices' => array(
                            'yes' => array(
                                'share_options' => array(
                                    'type'  => 'checkboxes',
                                    'value' => array(
                                        'is_fb'         => true,
                                        'is_twitter'    => true,
                                        'is_gp'         => true,
                                        'is_pinterest'  => true,
                                    ),
                                    'label' => esc_html__('Social Share sites.','appdown'),
                                    'desc'  => esc_html__('Mark as checked which want to keep as Social Share.', 'appdown'),
                                    'choices' => array( // Note: Avoid bool or int keys http://bit.ly/1cQgVzk
                                        'is_fb'         => esc_html__('Facebook','appdown'),
                                        'is_twitter'    => esc_html__('Twitter','appdown'),
                                        'is_gp'         => esc_html__('Google plus','appdown'),
                                        'is_pinterest'  => esc_html__('Pinterest','appdown'),
                                  
                                        'is_linkedin'   => esc_html__('Linkedin','appdown'),

                                    ),
                                    // Display choices inline instead of list
                                    'inline' => false,
                                )
                            ),
                        )
                    ),
                )
            ),
        )
    )
);
