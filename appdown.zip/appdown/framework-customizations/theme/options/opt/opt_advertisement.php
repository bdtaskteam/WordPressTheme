<?php

if (!defined('FW')) {
    die('Forbidden');
}

$options = array(
    'advertisement_opt' => array(
        'title' => esc_html__('Advertisement Settings','appdown'),
        'type' => 'tab',
        'options' => array(
     
            'category_ad_tab' => array(
                'title' => esc_html__('Category Page Ad','appdown'),
                'desc'  => esc_html__('The ad will appear on the bottom of the Category archive page.','appdown'),
                'type'  => 'tab',
                'options' => array(
                    'category_ad' => array(
                        'type'      => 'multi-picker',
                        'label'     => false,
                        'desc'      => false,
                        'picker'    => array(
                            'cat_ad_type' => array(
                                'type'      => 'switch',
                                'label'     => esc_html__('Advertise type','appdown'),
                                'desc'      => esc_html__('Switch through image and code type.', 'appdown'),
                                'left-choice'   => array(
                                    'value'     => 'cat_ad_image',
                                    'label'     => esc_html__('Image','appdown'),
                                ),
                                'right-choice'  => array(
                                    'value'     => 'cat_ad_code',
                                    'label'     => esc_html__('Code','appdown'),
                                ),
                            ),
                        ),
                        'choices' => array(
                            'cat_ad_image' => array(
                                'cat_ad_image' => array(
                                    'label'         => esc_html__('Header ad','appdown'),
                                    'type'          => 'upload',
                                    'images_only'   => true,
                                ),
                                'cat_ad_link' => array(
                                    'label'         => esc_html__('Header ad link','appdown'),
                                    'type'          => 'text',
                                    'value'         => '#',
                                ),
                            ),
                            'cat_ad_code' => array(
                                'cat_ad_code' => array(
                                    'type'      => 'textarea',
                                    'label'     => esc_html__('Header Ad Code','appdown'),
                                    'desc'      => esc_html__('Place here your Ad Code.', 'appdown'),
                                )
                            )
                        ),
                    )
                )
            ),
        )
    )
);
