<?php

if (!defined('FW')) {
    die('Forbidden');
}
$options = array(
    'social_links' => array(
        'title' => esc_html__('Social media','appdown'),
        'type' => 'tab',
        'options' => array(
            'social_links_box' => array(
                'title' => esc_html__('Social links','appdown'),
                'type' => 'tab',
                'options' => array(
                    'facebook'     => array(
                        'type'      => 'text',
                        'label'     => esc_html__('Facebook','appdown'),
                        'value'     => '#',
                    ),
                    'twitter'     => array(
                        'type'      => 'text',
                        'label'     => esc_html__('Twitter','appdown'),
                        'value'     => '#',
                    ),
                    'instagram'     => array(
                        'type'      => 'text',
                        'label'     => esc_html__('Instagram','appdown'),
                        'value'     => '#',
                    ),
                    'pinterest'     => array(
                        'type'      => 'text',
                        'label'     => esc_html__('Pinterest','appdown'),
                        'value'     => '#',
                    ),
                    'vimeo'     => array(
                        'type'      => 'text',
                        'label'     => esc_html__('Vimeo','appdown'),
                        'value'     => '#',
                    ),
                    'youtube'     => array(
                        'type'      => 'text',
                        'label'     => esc_html__('Youtube','appdown'),
                        'value'     => '#',
                    ),
                    'more_social_links' => array(
                        'type'  => 'addable-box',
                        'label' => esc_html__('Add more', 'appdown'),
                        'desc'  => esc_html__('Add more social links with icons','appdown'),
                        'box-options' => array(
                            'icon' => array( 'type' => 'icon', 'label' => esc_html__('Icon', 'appdown') ),
                            'link' => array( 'type' => 'text', 'label' => esc_html__('Link', 'appdown') ),
                        ),
                        'box-controls' => array( // buttons next to (x) remove box button
                            'control-id' => '<small class="dashicons dashicons-share"></small>',
                        ),
                        'limit' => 0, // limit the number of boxes that can be added
                        'add-button-text' => esc_html__('Add link','appdown'),
                        'sortable' => true,
                    ),
                )
            ),
            'social_center_widget' => array(
                'title' => esc_html__('Social Center Widget','appdown'),
                'type' => 'tab',
                'options' => array(
                    'add_social_net' => array(
                        'type'  => 'addable-box',
                        'label' => esc_html__('Add Social Network', 'appdown'),
                        'desc'  => esc_html__('Add social networks as you wish.','appdown'),
                        'box-options' => array(
                            'title'     => array( 'type' => 'text', 'label' => esc_html__('Title','appdown'), 'value' => 'Follow' ),
                            'icon'      => array( 'type' => 'icon', 'label' => esc_html__('Icon','appdown'), 'value' => 'fa fa-facebook' ),
                            'count'     => array( 'type' => 'text', 'label' => esc_html__('Follower count label','appdown'), 'value' => '4k Followers' ),
                            'bg_color'  => array( 'type' => 'color-picker', 'label' => esc_html__('Background color','appdown'), 'value' => '#3c599f' ),
                        ),
                        'template'      => 'Title: {{- title }}, Icon {{- icon}}',
                        'box-controls'  => array( // buttons next to (x) remove box button
                            'control-id' => '<small class="dashicons dashicons-share"></small>',
                        ),
                        'limit' => 0, // limit the number of boxes that can be added
                        'add-button-text' => esc_html__('Add more','appdown'),
                        'sortable' => true,
                    )
                )
            ),
        )
    )
);
