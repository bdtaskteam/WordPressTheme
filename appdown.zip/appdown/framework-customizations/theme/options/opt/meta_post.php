<?php

if (!defined('FW')) {
    die('Forbidden');
}

$options = array(


    

    // Pricing meta
    'app_info'   => array(
        'title'     => esc_html__('App Information', 'appdown'),
        'type'      => 'tab',
        'options'   => array(

        'upload_apps'  =>  array(
          'type'    => 'upload',
                'label'   => esc_html__('Upload Your App ', 'appdown'),
                'desc'    => esc_html__('doc , pdf , zip , apk  , Upload This ', 'appdown'),
                'images_only' => false,
                'files_ext' => array( 'doc', 'pdf', 'zip','apk','exe' ),
        ), 
        'app_companny'  =>  array(
        'type'  => 'text',
        'value' => '',
        'label' => __('App Company Name  ', 'appdown'),
         'value' => 'bdtask',
        ),
        'app_free'  =>  array(
        'type'  => 'text',
        'value' => '',
        
        'label' => __('App Free Or By ', 'appdown'),
        'desc'  => __('Free Or By Button Level', 'appdown'),
        ),

        'publish_date'  =>  array(
        'type'  => 'date-picker',
        'value' => '',
        
        'label' => __('Publish Date', 'appdown'),
        'desc'  => __('Select  Publish Date', 'appdown'),
        ),  
        'app_version'  =>  array(
        'type'  => 'text',
        'value' => '1.3.6',
        
        'label' => __('App Requirements ', 'appdown'),
        'desc'  => __('Write  App Requirements', 'appdown'),
        ),
        'app_requirements'  =>  array(
        'type'  => 'text',
        'value' => 'Android 5.0+',
        
        'label' => __('App Requirements ', 'appdown'),
        'desc'  => __('Write  App Requirements', 'appdown'),
        ),   

        'app_size'  =>  array(
        'type'  => 'text',
        'value' => '12 MB',
        
        'label' => __('App Size ', 'appdown'),
        'desc'  => __('Write  App Size', 'appdown'),
        ),   
      'app_author'  =>  array(
        'type'  => 'text',
        'value' => 'Fighter.im',
        
        'label' => __('App Author ', 'appdown'),
        'desc'  => __('Write  App Author', 'appdown'),
       
        ), 
       'get_it_on'  =>  array(
        'type'  => 'text',
        'value' => 'Google Play',
        
        'label' => __('Get it on', 'appdown'),
        'desc'  => __('Write  Get it on', 'appdown'),

        ),

    )
 ),

    // Pricing meta
    'post_meta'   => array(
        'title'     => esc_html__('Gellary ', 'appdown'),
        'type'      => 'tab',
        'options'   => array(
         
                'tour_gallery' => array(
                'type'     => 'multi-upload',
                'label'    => esc_html__('Gallery', 'appdown'),
                'desc'     => esc_html__('Upload here images for tour package gallery.', 'appdown'),
                'size'     => 'small', // small, large
                'editor_height' => 400,
                'wpautop'       => true,
                'editor_type'   => false,
            ),
        )
    ),

// discription 

    'post_dis'   => array(
        'title'     => esc_html__('Discriptions ', 'appdown'),
        'type'      => 'tab',
        'options'   => array(
         
            'app_short_dis' => array(
            'type' => 'wp-editor',
            'tinymce' => true,
            'size' => 'large',
            'reinit' => true,
            'wpautop' => false,
            'editor_height' => 100,
            'editor_type' => 'html',
            'value' => 'This is dummy heading text',
            'label' => __('Heading', 'appdown'),
            'desc' => __('Add heading text', 'appdown')
        ),






        )
    ),

    'post_dis_reviews'   => array(
        'title'     => esc_html__('Reviews Discriptions ', 'appdown'),
        'type'      => 'tab',
        'options'   => array(
         
          'app_short_revew' => array(
            'type'  => 'wp-editor',
            'value' => 'default value',
            'label' => __('Label', 'appdown'),
            'desc'  => __('Description', 'appdown'),
            'help'  => __('Help tip', 'appdown'),
            'size' => 'small', 
            'wpautop' => true,
            'editor_type' => false, 
               
            ),
        )
    ),


      'post_dis_specifications'   => array(
        'title'     => esc_html__('Specifications Discriptions ', 'appdown'),
        'type'      => 'tab',
        'options'   => array(
         
          'app_short_speci' => array(
            'type'  => 'wp-editor',
            'value' => 'default value',
            'label' => __('Label','appdown'),
            'desc'  => __('Description','appdown'),
            'help'  => __('Help tip','appdown'),
            'size' => 'small', // small, large
            'wpautop' => true,
            'editor_type' => false, 
               
            ),

         


        ),
    ),


);
