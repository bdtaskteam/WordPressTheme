<?php

if (!defined('FW')) {
    die('Forbidden');
}

$options = array(
    'gallery_config'   => array(
        'title'     => esc_html__('Gallary Settings ','appdown'),
        'type'      => 'tab',
        'options'   => array(

             'bg_image'=>array(
              
                'type'    => 'upload',
                'label'   => esc_html__('Slide Background Image ','appdown'),
                'desc'    => esc_html__('Select a Image for the slide item.','appdown'),
             ),

            'g_item_column' => array(
                'type'    => 'upload',
                'label'   => esc_html__('Slide small Image  ','appdown'),
                'desc'    => esc_html__('Must Select a image for the slide item  size 157 x 326 pixel .', 'appdown'),
                  
            ),   
            'g_item_sub' => array(
                'type'    => 'upload',
                'label'   => esc_html__('Slide small Image ','appdown'),
                'desc'    => esc_html__(' Must Select a image for the slide item  size 134 x 277pixel','appdown'),
                  
            ),
            
            's_main_title' => array(
                'type'    => 'text',
                'value'   =>'CBS All ACCESS FOR SUNDAY',
                'label'   => esc_html__('Slider Main Title','appdown'),
            ),      

            's_sub_title' => array(
                'type'    => 'text',
                 'value'  =>'THURSDAY NIGHT GAMES',
                'label'   => esc_html__('Slider Sub Title','appdown'),
            ),   

            's_discription' => array(
                'type'    => 'textarea',
                 'value'  =>'Following several years on Twitter, this year Thursday to Amazon video service With a Prime gmobile device or TV',
                'label'   => esc_html__('Slider Sub Title','appdown'),
            ),
             


        )

    ),
    

    'gallery_configsdfgsfdg'   => array(
        'title'     => esc_html__('Slider  Button','appdown'),
        'type'      => 'tab',
        'options'   => array(

               'app_sotre' => array(
                'type'    => 'text',
                'value'   =>'#',
                'label'   => esc_html__('App Sotre ','appdown'),
                'desc'    => esc_html__('App Store Link ','appdown'),
              
            ),

             'app_sotre_image' =>array(

                'type' =>'upload',
                'label'   => esc_html__('Google Paly Sotre logo  ','appdown'),
                'desc'    => esc_html__('This is section image Size 122 x 36 pixel','appdown'),
             )  
                ,
            'play_store' => array(
                'type'    => 'text',
                'value'   =>'#',
                'label'   => esc_html__('Google Paly Sotre  ','appdown'),
                'desc'    => esc_html__(' Play Store Link ','appdown'),
                  
            ),
            'play_store_image' =>array(

                'type' =>'upload',
                'label'   => esc_html__('Apple App Sotre logo  ','appdown'),
                'desc'    => esc_html__('This is section image Size 122 x 36 pixel','appdown'),
             ) , 

            'g_item_app' => array(
                'type'    => 'upload',
                'label'   => esc_html__('Upload Your App ', 'appdown'),
                'desc'    => esc_html__('doc , pdf , zip , apk  , Upload This ','appdown'),
                   'images_only' => false,
                     'files_ext' => array( 'doc', 'pdf', 'zip','apk' ),
            ),




        )

    ),


);
