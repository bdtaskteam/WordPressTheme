<?php

if (!defined('FW')) {
    die('Forbidden');
}

$options = array(
    'opt_typo'  => array(
        'title'     => esc_html__('Typography Settings','appdown'),
        'type'      => 'tab',
        'options'   => array(
            'main_font' => array(
                'label' => esc_html__('Main Font Properties','appdown'),
                'desc'  => esc_html__('Basically the main font used in all title text.', 'appdown'),
                'type'  => 'typography-v2',
                'value' => array(
                    'family'        => 'Roboto',
                    'font-weight'   => '600'
                ),
                'components' => array(
                    'family'         => true,
                    'size'           => false,
                    'line-height'    => false,
                    'color'          => false,
                    'style'          => false,
                    'script'         => false,
                    'letter-spacing' => false,
                ),
            ),
            'secondary_font' => array(
                'label' => esc_html__('Secondary Font Properties','appdown'),
                'desc'  => esc_html__('Basically the secondary font is used to paragraph type text.', 'appdown'),
                'type'  => 'typography-v2',
                'value' => array(
                    'family'        => 'Open Sans',
                    'font-weight'   => '400'
                ),
                'components' => array(
                    'family'         => true,
                    'size'           => false,
                    'line-height'    => false,
                    'color'          => false,
                    'style'          => false,
                    'script'         => false,
                    'letter-spacing' => false,
                ),
            ),
        )
    )
);
