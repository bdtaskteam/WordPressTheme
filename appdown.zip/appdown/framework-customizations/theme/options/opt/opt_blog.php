<?php

if (!defined('FW')) {
    die('Forbidden');
}
$options = array(
    'blog_opt' => array(
        'title' => esc_html__('Blog settings','appdown'),
        'type' => 'tab',
        'options' => array(
            'blog_title'  => array(
                'type'          => 'text',
                'label'         => esc_html__('Blog title','appdown'),
                'value'         => 'Blog Post'
            ),
           
            'blog_read_more'  => array(
                'type'          => 'text',
                'label'         => esc_html__('Read more text','appdown'),
                'value'         => 'read more'
            ),
            'blog_excerpt'  => array(
                'type'          => 'text',
                'label'         => esc_html__('Post word excerpt','appdown'),
                'value'         => 30
            ),
        
        )
    )
);
