<?php if ( ! defined( 'FW' ) ) {
    die( 'Forbidden' );
}
/**
 * Framework options
 *
 * @var array $options Fill this array with options to generate framework settings form in backend
 */

$options = array(
    fw()->theme->get_options( 'opt/opt_header' ),
     fw()->theme->get_options( 'opt/opt_home_cat' ),
    fw()->theme->get_options( 'opt/opt_page_settings' ),
    fw()->theme->get_options( 'opt/opt_blog' ),
    fw()->theme->get_options( 'opt/opt_advertisement' ),
    fw()->theme->get_options( 'opt/opt_single_post' ),
    fw()->theme->get_options( 'opt/opt_colors' ),
    fw()->theme->get_options( 'opt/opt_typo' ),
    fw()->theme->get_options( 'opt/opt_tour' ),
    fw()->theme->get_options( 'opt/opt_footer' ),
    
);
