<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @package Appdown
 */
$mc_form_title    = defined('FW') ? fw_get_db_settings_option('mc_form_title') : '';
$mc_form_subtitle    = defined('FW') ? fw_get_db_settings_option('mc_form_subtitle') : '';
$mc_level    = defined('FW') ? fw_get_db_settings_option('mc_level') : '';
$mc_button_link    = defined('FW') ? fw_get_db_settings_option('mc_button_link') : '';
$mc_form_imag    = defined('FW') ? fw_get_db_settings_option('mc_form_imag') : '';
$mc_form_imag  = isset($mc_form_imag['url']) ? $mc_form_imag['url'] : '';
$copyright_text    = defined('FW') ? fw_get_db_settings_option('copyright_text') : '<a class="nav-link" href="#">©2017 Google Site</a>';
?>

  <!--========== Creative Business Area ==========-->
        <div class="business_area">
            <div class="container">
                <div class="row m0 business_inner" style="background: url(<?php echo esc_url(
                    $mc_form_imag)?>)">
                    <div class="col-md-8 offset-md-4">
                        <div class="business_details">
                            <?php if(!empty($mc_form_title)){?>
                            <h2 class="first_heading wow fadeInUp"><?php echo  esc_html($mc_form_title) ; ?></h2>
                            <?php }if(!empty($mc_form_subtitle)){?>
                            <h2 class="sub_heading wow fadeInDown"><?php echo esc_html ($mc_form_subtitle); ?></h2>
                             <?php }?>
                        </div> 
                        <div class="button_area align-self-end">
                            <a class="base_button hover_style" href="<?php echo esc_url($mc_button_link); ?>"><?php echo esc_html($mc_level); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--========== End Creative Business Area ==========-->
        
        <!--========== Footer Area ==========-->
        <footer>
            <div class="container">
                <div class="row m0 footer_inner">
                    <div class="menu_area">
                        <ul class="nav justify-content-center">
                            <li class="nav-item">
                                <?php echo $copyright_text;?>
                            </li>
                       
                          <?php
            
                         wp_nav_menu( array(
                         'theme_location' => 'footer_menu', // Defined when registering the menu
                         'menu_id'        => 'footer_menu',
                         'container'      => false,
                         'depth'          => 2,
                         'menu_class'     => 'nav justify-content-center',
                         'walker'         => new bs4Navwalker(), // This controls the display of the Bootstrap Navbar
                         'fallback_cb'    => 'bs4Navwalker::fallback', // For menu fallback
                         ) );?>

                        </ul>


                    </div>
                </div>
            </div>
        </footer>
        <!--========== End Footer Area ==========-->

    
        <a href="#0" class="cd-top">
            <i class="fa fa-chevron-up"></i>
        </a>


<?php wp_footer(); ?>

</body>
</html>
