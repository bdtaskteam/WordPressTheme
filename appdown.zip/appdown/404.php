<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Appdown
 */

get_header(); ?>







        
        <!--========== Appstore Area ==========-->
        <section class="appstore_area">
            <div class="container">
                <div class="row appstore_inner container_section">
                   
                    
                    <div class="col-lg-12">
                        <div id="content" class="error404_content">
                            <div class="row m0 blog_area wow fadeInDown">
                              
				                   <div class="blog_page">
        
   
   									     <div class="content_area">
         
            								<p class="error404"> 
             							   <h1 class="error404"><?php echo esc_html__('404 ERROR', 'appdown'); ?></h1>
           								   <h3 class="error404"><?php echo esc_html__('The page you were looking for does not exist.', 'appdown'); ?></h3>
              

           								 </p>
            <a href="<?php echo esc_url(home_url('/')); ?>" class="base_button hover_style"><?php echo esc_html__('Go back Home', 'appdown'); ?> </a>
               
       									 </div>
   									 </div>
		
		
                            </div>
                   
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--========== End Appstore Area ==========-->

<?php

get_footer();

