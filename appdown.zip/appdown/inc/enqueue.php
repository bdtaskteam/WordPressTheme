<?php

/**
 * Enqueue scripts and styles.
 */
function appdown_scripts() {
    /**
     * Register Google fonts.
     *
     * @return string Google fonts URL for the theme.
     */
    function appdown_fonts_url() {

        $fonts_url = '';
        $fonts     = array();
        $subsets   = '';

        $main_font  = defined('FW') ? fw_get_db_settings_option('main_font') : '';
        $main_ff    = isset($main_font['family']) ? esc_attr($main_font['family']) : 'Roboto';

        $secondary_font = defined('FW') ? fw_get_db_settings_option('secondary_font') : '';
        $secondary_ff   = isset($secondary_font['family']) ? esc_attr($secondary_font['family']) : 'Open Sans';

        /* translators: If there are characters in your language that are not supported by this font, translate this to 'off'. Do not translate into your own language. */
        if ( 'off' !== esc_html_x( 'on', esc_html($secondary_ff).' font: on or off', 'appdown' ) ) {
            $fonts[] = esc_html($secondary_ff).':400,600,700,800';
        }

        /* translators: If there are characters in your language that are not supported by this font, translate this to 'off'. Do not translate into your own language. */
        if ( 'off' !== esc_html_x( 'on', esc_html($main_ff).' font: on or off', 'appdown' ) ) {
            $fonts[] = esc_html($main_ff).':400,500,700';
        }

        if ( $fonts ) {
            $fonts_url = add_query_arg( array(
                'family' => urlencode( implode( '|', $fonts ) ),
                'subset' => urlencode( $subsets ),
            ), 'https://fonts.googleapis.com/css' );
        }

        return $fonts_url;
    }

 
?>

<?php 

 wp_enqueue_style('appdown-fonts', appdown_fonts_url(), array(), null);
 wp_enqueue_style('bootstrap', get_template_directory_uri() . '/vendor/bootstrap/css/bootstrap.min.css');
 wp_enqueue_style('wow-css', get_template_directory_uri() . '/vendor/wow-js/animate.css');
 wp_enqueue_style('font-awesome', get_template_directory_uri() . '/vendor/font-awesome/css/font-awesome.min.css');
 wp_enqueue_style('camera_slider', get_template_directory_uri() . '/vendor/camera_slider/css/camera.css');
  wp_enqueue_style('owl-carousel', get_template_directory_uri() . '/vendor/owl-carousel/css/owl.carousel.min.css');
 wp_enqueue_style('appdown-main', get_template_directory_uri() . '/assets/css/style.css');
 wp_enqueue_style('responsive', get_template_directory_uri() . '/assets/css/responsive.css');

    if(is_rtl()) {
        wp_deregister_style('appdown-main'); 
    }

    $dynamic_css = '';

    if(defined('FW')) {

        $accent_color = defined('FW') ? fw_get_db_settings_option('accent_color') : '';
        $accent_colorvbncvbnvc = defined('FW') ? fw_get_db_settings_option('accent_colorvbncvbnvc') : ''; 
        $accent_all_white = defined('FW') ? fw_get_db_settings_option('accent_all_white') : '';
        $header_color = defined('FW') ? fw_get_db_settings_option('header_color') : '';
        $accent_all_black = defined('FW') ? fw_get_db_settings_option('accent_all_black') : ''; 
        $footer_color = defined('FW') ? fw_get_db_settings_option('footer_bg_color') : '';
        $main_font = fw_get_db_settings_option('main_font');
        $main_ff = isset($main_font['family']) ? esc_attr($main_font['family']) : 'Roboto';
        $secondary_font = fw_get_db_settings_option('secondary_font');
        $secondary_ff = isset($secondary_font['family']) ? esc_attr($secondary_font['family']) : 'Open Sans';

        $dynamic_css .= '
                      .page_header .page_header_inner .page_title,
                      .header_part .header .nav .nav-item .nav-link span, 
                      .header_part .header .nav .nav-item .search_icon span,
                      .comments_area .request_form button ,
                      .chat_apps .chat_apps_details p,
                      .users_rating .editors_rating p,
                      .quick_apps .tab-content .tab-pane .single_apps .single_apps_inner .apps_title,
                      .appdown_apps .apps_store .single_apps .single_apps_inner .apps-title ,
                      .apps_review .tab-content .tab-pane a,
                      .pagination_part nav .pagination .page-item .page-link ,
                      .apps_category_part .apps_category .item_info h4 ,
                      .apps_category_part .apps_category .item_info .blog-title ,
                      .contact_area .contact_inner .comments_area .request_form button,
                      .blog_area .post_heading,
                      .camera_caption .base_button,
                       a ,h2, h3, h4, h5, h6 {
                        font-family: \''.esc_attr($main_ff).'\', sans-serif;
                    }
                    .blog_area .post_author li ,
                    .blog_area .blog_page .content_area p,
                    .blog_area .blog_details .single_blog blockquote,
                    .apps_category_part .apps_category .item_info p ,
                     p
                     {
                        font-family: \''.esc_attr($secondary_ff).'\', sans-serif;
                     }

                   
                .headline:before ,
                .base_button ,
                .hover_style ,
                .header_part .header .nav .nav-item.dropdown .dropdown-menu .dropdown-item,
                .animated_search_box .search_icon,
                .animated_search_box .hidden_search_box .search-form input ,
                .navbar-toggler-right,
                .banner_area .banner .banner_inner .btn,
                .business_area .business_inner .button_area a,

                .appstore_area .appstore_inner .popular_download .popular_items .single_item:hover ,
                .comments_area .request_form button,
                .chat_apps .chat_apps_details .nav.download_button .nav-item .nav-link.free_btn ,
                .chat_apps .chat_apps_details .nav.download_button .nav-item .nav-link.purchase_btn:hover ,
                .users_rating .download_btn,
                .quick_apps .nav .nav-item .nav-link.active, .quick_apps .nav .nav-item .nav-link:hover,
                .apps_categories h3,
                .apps_categories .cat-item p:hover ,
                .apps_review .nav .nav-item .nav-link:before,
                .apps_review .tab-content .tab-pane a:hover,
                .blog_area .blog_details .single_blog .social_area .social_apps .nav .nav-item .nav-link:hover,
                .blog_area .blog_details .single_blog .social_area .social_icon .nav .nav-item .nav-link:hover,
                .pagination_part nav .pagination .page-item .page-link:hover,
                .camera_wrap .camera_pag .camera_pag_ul li,
                .camera_wrap .camera_pag .camera_pag_ul li.cameracurrent,
                .camera_caption .base_button,
                .camera_prev, .camera_next ,
                .cd-top ,
                .contact_area .contact_inner .comments_area .request_form button,
                .appstore_area .appstore_inner .popular_download .popular_items  a,.reply_area a,
                .header_part .header .nav .nav-item .nav-link:hover, .header_part .header .nav .nav-item .search_icon:hover,
                .header_part .header .nav .nav-item .nav-link.active, .header_part .header .nav .nav-item .search_icon.active{

                background-color: ' . esc_attr($accent_color) . ' !important;
                }
            .rate-container > i,
            .quick_apps .tab-content .tab-pane .single_apps .single_apps_inner .apps_title:hover,
            .appdown_apps .apps_store .single_apps:hover .apps-title,.page-numbers,.business_area .business_inner .business_details .sub_heading,.camera_commands .camera_play i, .camera_commands .camera_stop i,
            .header_part .header .nav .nav-item .search_icon i,.camera_caption .base_button:hover,.page_header .page_header_inner .page_title,.blog_area .post_heading,footer .footer_inner .menu_area ul li a:hover{
             color: ' . esc_attr($accent_color) . ' !important;
             }

             .appstore_area .appstore_inner .popular_download .popular_items .single_item:hover .item_details a ,.current, .page-numbers:hover{
                color:'.esc_attr($accent_color).'!important; 
                background: ' . esc_attr($accent_colorvbncvbnvc) . ' !important;
            }
          .header_part .header .nav .nav-item .nav-link span, .header_part .header .nav .nav-item .search_icon span,.page_header .page_header_inner .breadcrumb li a ,
         .hover_style:before,
          .header_part .header .nav .nav-item .search_icon span,
         .appstore_area .appstore_inner .download_part p,
         .users_rating .editors_rating h5,.users_rating .editors_rating p,
        
         .quick_apps .tab-content .tab-pane .single_apps .single_apps_inner .apps_title ,
         .appdown_apps .apps_store .single_apps .single_apps_inner .apps-title ,
         .apps_categories .cat-item a ,
         .apps_review .nav .nav-item .nav-link,
         .blog_area .post_heading:hover,.blog_area .post_author li,.blog_area .blog_page .content_area p,
         .blog_area .blog_details .single_blog .social_area .social_icon .nav .nav-item .nav-link,
         .apps_category_part .apps_category .item_info h4 ,
         .apps_category_part .apps_category .item_info .blog-title,
         .camera_target:before ,.text-justify,.apps_review .tab-content .tab-pane h3,ul li,.headline,.reply_area .member .member_details,.widget_archive ul li a,
         .chat_apps .chat_apps_details h2,.date_publish,.requirements_version, .file_size, .author,.source, .file, .appstore_area .appstore_inner .download_part h5,.chat_apps .chat_apps_details h4,.apps_version{

            color: ' . esc_attr($accent_all_black) . ' !important;
            }
             
           .header_part .header .nav .nav-item .nav-link:hover span, .header_part .header .nav .nav-item .search_icon:hover span, .header_part .header .nav .nav-item .nav-link.active span, .camera_caption h2,.camera_caption h3,.camera_caption p,.base_button, .hover_style,.banner_area .banner .card .card-img-overlay .card-title, .banner_area .banner .card .card-img-overlay .card-text,.inner-wrapper-sticky h3,.appstore_area .appstore_inner .popular_download .popular_items .single_item .item_details a,
             .business_area .business_inner .business_details h2,.chat_apps .chat_apps_details .nav.download_button .nav-item .nav-link,footer .footer_inner .menu_area ul li a{
              color: ' . esc_attr($accent_all_white) . ' !important;
             
             }
             .header_part{
                background: ' . esc_attr( $header_color) . ' !important;
             }
             footer{
                background:' . esc_attr( $footer_color) . ' !important;
             }

            ';



    }
    // Page settings css
    $page_ptop = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'page_ptop') : '0px';
    $page_pbtm = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'page_pbtm') : '0px';
    $dynamic_css .= '.page-content {
                            padding-top: ' . esc_attr($page_ptop) . ';
                            padding-bottom: ' . esc_attr($page_pbtm) . ';
                        }';

    wp_add_inline_style('appdown-main', $dynamic_css);

wp_enqueue_style( 'appdown-root-stylesheet', get_stylesheet_uri() );
    // Scripts
    
wp_enqueue_script( 'tether-min', get_template_directory_uri() . '/vendor/bootstrap/js/tether.min.js', array('jquery'), true );
wp_enqueue_script( 'bootstraps', get_template_directory_uri() . '/vendor/bootstrap/js/bootstrap.min.js', array('jquery'), true );

wp_enqueue_script( 'jquery-easing', get_template_directory_uri() . '/vendor/camera_slider/js/jquery.easing.1.3.js', array('jquery'), true );
wp_enqueue_script( 'camera-min', get_template_directory_uri() . '/vendor/camera_slider/js/camera.min.js', array('jquery'), true );
wp_enqueue_script( 'owl-carousel', get_template_directory_uri() . '/vendor/owl-carousel/js/owl.carousel.min.js', array('jquery'), true );

wp_enqueue_script( 'sticky-sidebar', get_template_directory_uri() . '/vendor/sticky-sidebar/sticky-sidebar.min.js', array('jquery'), true );
wp_enqueue_script( 'custom-sticky-sidebar', get_template_directory_uri() . '/vendor/sticky-sidebar/custom-sticky-sidebar.js', array('jquery'), true );

wp_enqueue_script( 'cussdfgsdfgsdfgsdfgdfgtom-camera', get_template_directory_uri() .'/vendor/camera_slider/js/custom-camera.js', array('jquery'), true );
wp_enqueue_script( 'wow-js', get_template_directory_uri() . '/vendor/wow-js/wow.min.js', array('jquery'), true );

 wp_enqueue_script( 'appdown-custom-wp', get_template_directory_uri(). '/assets/js/custom.js', array('jquery'), '1.0', true );

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'appdown_scripts' );



