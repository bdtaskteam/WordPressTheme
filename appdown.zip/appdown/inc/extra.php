<?php 
/**
 * Custom functions that act independently of the theme templates
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package sppdown
 */



function bdt_pagetitlebar() {
    ?>
  
<?php 
  $blog_titles = defined('FW') ? fw_get_db_settings_option('blog_titles') : esc_html__('Blog', 'appdown');?>
   <section class="page_header">
            <div class="container">
                <div class="row m0 page_header_inner">
                    <h2 class="page_title">
                    	
                               <?php
                                 
                        if (is_page() || is_single()) {
                            the_title();
                        }
                        elseif (is_home()) {
                            echo esc_html($blog_titles);
                        }
                     
                        elseif(is_search()) {
                            printf( esc_html__( 'Search Results for: %s', 'appdown' ), '<strong>' . get_search_query() . '</strong>' );
                        }
                        elseif(is_category()) {
                            the_archive_title();
                        }
                        elseif(is_tag()) {
                            esc_html_e('Tag: ', 'appdown');
                            single_tag_title();
                        }
                        elseif(is_404()) {
                            esc_html_e('404 error', 'appdown');
                        }
                        elseif(is_archive()) {
                            the_archive_title();
                        }

                            
                            
                        ?>

                    </h2>
           
                    <?php bdt_breadcrumbs(); ?>
                </div>
            </div>
        </section>






    <?php
}

// Post social share options
function bdt_social_share() {
    $post_share     = defined('FW') ? fw_get_db_settings_option('post_share') : '';
    $is_fb          = isset($post_share['yes']['share_options']['is_fb']) ? $post_share['yes']['share_options']['is_fb'] : '';
    $is_twitter     = isset($post_share['yes']['share_options']['is_twitter']) ? $post_share['yes']['share_options']['is_twitter'] : '';
    $is_gp          = isset($post_share['yes']['share_options']['is_gp']) ? $post_share['yes']['share_options']['is_gp'] : '';
    $is_pinterest   = isset($post_share['yes']['share_options']['is_pinterest']) ? $post_share['yes']['share_options']['is_pinterest'] : '';
    $is_stumbleupon = isset($post_share['yes']['share_options']['is_stumbleupon']) ? $post_share['yes']['share_options']['is_stumbleupon'] : '';
    $is_linkedin    = isset($post_share['yes']['share_options']['is_linkedin']) ? $post_share['yes']['share_options']['is_linkedin'] : '';
    $is_tumblr      = isset($post_share['yes']['share_options']['is_tumblr']) ? $post_share['yes']['share_options']['is_tumblr'] : '';
    $is_reddit      = isset($post_share['yes']['share_options']['is_reddit']) ? $post_share['yes']['share_options']['is_reddit'] : '';
    $is_delicious   = isset($post_share['yes']['share_options']['is_delicious']) ? $post_share['yes']['share_options']['is_delicious'] : '';
    ?>
    <ul class="social_side_links">
        <?php if($is_fb == 1) { ?>
            <li>
              <a class="fb-icon" href="https://facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" target="_blank"><i class="fa fa-facebook"></i></a></li>
        <?php
        }
        if($is_pinterest == 1) { ?>
              <li><a class="pesbin_icon" href="https://www.pinterest.com/pin/create/button/?url=<?php the_permalink() ?>"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li> 
        <?php
        }
        if($is_twitter == 1) { ?>
            <li>
               <a class="ttr-icon" href="https://twitter.com/intent/tweet?text=<?php the_permalink(); ?>" target="_blank">
                    <i class="fa fa-twitter"></i></a> </li>
        <?php
        }
        if($is_gp == 1) { ?>
            <li>
              <a class="google-icon" href="https://plus.google.com/share?url=<?php the_permalink() ?>" target="_blank"><i class="fa fa-google"></i></a> </li> 
            <?php
        }
        if($is_linkedin == 1) { ?>
            <li>
                <a class="linked-icon" href="http://www.linkedin.com/shareArticle?url=<?php the_permalink(); ?>&title=<?php the_title(); ?>" target="_blank">
                    <i class="fa fa-linkedin"></i>
                </a> </li> <?php
        }
      ?>
        
     
    </ul>
    <?php
}


// rating

function bdt_tour_ratings() {
    $rating = get_comment_meta(get_comment_ID(), 'ratings', true);
    switch($rating) {
        case '1':
            $rating = '<i class="fa fa-star"></i>';
            break;
        case '2':
            $rating = '<i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>';
            break;
        case '3':
            $rating = '<i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>';
            break;
        case '4':
            $rating = '<i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>';
            break;
        case '5':
            $rating = '<i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>';
            break;
        default:
            $rating = esc_html__('Not rated', 'appdown');
    }
    echo $rating;
}

function bdt_get_avg_rating($post_type, $postID) {
    $comments = get_comments (array (
        'meta_key'  => 'ratings',
        'status'    => 'approve',
        'post_type' => $post_type,
        'post_id'   => $postID
    ));
    $ratings = array();
    foreach($comments as $comment) {
        $ratings[] = get_comment_meta($comment->comment_ID, 'ratings', true);
    }
    $total_ratings = count($ratings);
    $sum_ratings   = array_sum($ratings);
    $average_ratings = $sum_ratings>0 ? $sum_ratings/$total_ratings : '';
    $average_ratings = round(($average_ratings*2), 0)/2;
    return $average_ratings;
}


function bdt_avg_star_rating($post_type, $postID) {
    $avg_rating = bdt_get_avg_rating($post_type, $postID);
    switch($avg_rating) {
        case '1':
            $ratings = '<i class="fa fa-star"></i>';
            break;
        case '1.5':
            $ratings = '<i class="fa fa-star"></i>
                        <i class="fa fa-star-half"></i>';
            break;
        case '2':
            $ratings = '<i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>';
            break;
        case '2.5':
            $ratings = '<i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-half"></i>';
            break;
        case '3':
            $ratings = '<i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>';
            break;
        case '3.5':
            $ratings = '<i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-half"></i>';
            break;
        case '4':
            $ratings = '<i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>';
            break;
        case '4.5':
            $ratings = '<i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-half"></i>';
            break;
        case '5':
            $ratings = '<i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>';
            break;
        default:
            $ratings = esc_html__('Not rated', 'appdown');
    }
    echo $ratings;
}


/**
 * @param $comment
 * @param $args
 * @param $depth
 * Review list in the tour single page







 */
function bdt_reviews($comment, $args, $depth){
    $GLOBALS['comment'] = $comment;
    extract($args, EXTR_SKIP);
    ?>
    <li id="comment-<?php comment_ID(); ?>">
        <div class="comment-main-level">
            <div class="comment-avatar"><?php echo get_avatar($comment, 80 ); ?></div>
            <div class="comment-box">
                <div class="comment-content">
                    <cite class="comment-author"> <?php comment_author(); ?> </cite>
                    <div class="review_rating">
                        <?php bdt_tour_ratings(); ?>
                    </div>
                    <?php comment_text(); ?>
                </div>
            </div>
        </div>
    </li>
    <?php
}

// Adding rating field to single page review form
add_filter ('comment_form_default_fields','bdt_add_review_field', 10, 1);
function bdt_add_review_field ($fields) {
  
        $fields['ratings'] = '<div class="row address_form"><div class="col-md-12">
                            <div class="form-group">
                              <select name="ratings" class="form-control" id="sel1">
                                <option value="" selected="">'.esc_html__('Rating', 'appdown').'</option>
                                <option value="1">'.esc_html__('1 (lowest)', 'appdown').'</option>
                                <option value="2">'.esc_html__('2', 'appdown').'</option>
                                <option value="3">'.esc_html__('3', 'appdown').'</option>
                                <option value="4">'.esc_html__('4', 'appdown').'</option>
                                <option value="5">'.esc_html__('5 (best)', 'appdown').'</option>
                              </select>
                            </div>
                             </div></div>';
        return $fields;
}
// Save the rating field value
add_action ('comment_post', 'bdt_save_review_field_meta_value', 10, 1);
function bdt_save_review_field_meta_value ($comment_id) {
    if(isset($_POST['ratings'])) {
        // sanitize data
        $ratings = wp_filter_nohtml_kses($_POST['ratings']);
        // store data
        add_comment_meta ($comment_id, 'ratings', $ratings, false);
    }
}


/*
Comment List Function
*/
if(!function_exists('resuma_comments')){
    function resuma_comments($comment,$args,$depth){
        $GLOBALS['comment'] = $comment;
        extract($args, EXTR_SKIP);
        ?>
     
    <div class="row reply_area ptb-20"  id="comment-<?php comment_ID(); ?>">
            <div class="col-lg-6">
               <div class="media member" >
                    <?php
                    if(get_avatar($comment)) {
                        echo get_avatar($comment, 80,null,null,array('class'=>array('d-flex')));
                    } else {
                        echo '<img src="'.get_template_directory().'/avatar.png" alt="" class="d-flex">';
                    }
                    ?>
                <div class="media-body member_details">
                        <h5><?php comment_author(); ?></h5>
                        <h6> <?php echo get_comment_date() ?> <?php esc_html_e('at', 'appdown'); ?> <?php the_time('g:i a'); ?> </h6>
                       
                         <div class="rating_area">
                            <div class="rate-container">
                             <?php bdt_tour_ratings(); ?>
                            </div>
                        </div>
                        <?php comment_text(); ?>
           
                  
                     <div class="text-right user-action">
                    <p><?php comment_reply_link( array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?></p>
                </div>
                      
                   <!-- </div> -->
                </div>
            </div>
        </div>
    </div>


        <?php
    }
}




























