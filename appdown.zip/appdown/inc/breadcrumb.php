<?php

// Breadcrumbs
function bdt_breadcrumbs() {

    $blog_title = defined('FW') ? fw_get_db_settings_option('blog_title') : esc_html__('Blog', 'appdown');

    echo '<ol class="breadcrumb m0 p0">';
    if (!is_home() & !is_author() & !is_search() & !is_tag() & !is_404() & !is_archive() ) {
        echo '<li class="breadcrumb-item">';
        echo '<a href="';
        echo esc_url(home_url('/')).'">';
        echo esc_html__('Home ', 'appdown');
        echo "</a></li>";
        

        if (is_category() || is_single()) {
            echo '<li class="breadcrumb-item"><a href="'.get_post_type_archive_link( 'post' ).'">'.esc_html__('Blog', 'appdown').'</a></li>';
            
            the_category(' <li class="breadcrumb-item active"> <a href="'.get_the_permalink().'"> </a></li> ');
        }
        elseif (is_page()) {
            echo '<li class="breadcrumb-item active"><a href="'.get_the_permalink().'"> &nbsp;';
            echo ''.get_the_title().'</a></li>';
            
        }
    }
    elseif (is_home()) { ?>
        <li class="breadcrumb-item">
        <a href="<?php echo esc_url(home_url('/')); ?>"> <?php esc_html_e('Home', 'appdown'); ?> </a></li>
        <?php echo '<li class="breadcrumb-item active">'.esc_html($blog_title).'</li>';
    }
    elseif (is_author()) { ?>
       <li class="breadcrumb-item">
        <a href="<?php echo esc_url(home_url('/')); ?>"> <?php esc_html_e('Home', 'appdown'); ?> </a></li>
       <li class="breadcrumb-item active"> <a href="<?php the_author_link(); ?>"> <?php echo get_the_author_meta('display_name'); ?> </a></li>
        <?php
    }
    elseif (is_tag()) { ?>
    <li class="breadcrumb-item">
       <a href="<?php echo esc_url(home_url('/')); ?>"> <?php esc_html_e('Home', 'appdown'); ?> </a></li>
       <li class="breadcrumb-item active"> <a href=""> <?php echo ''; single_tag_title(); ?> 
       </a></li>
        <?php
    }
    elseif (is_404()) { ?>
      <li class="breadcrumb-item">
        <a href="<?php echo esc_url(home_url('/')); ?>"> <?php esc_html_e('Home', 'appdown'); ?> </a></li>
       <li class="breadcrumb-item active"> <?php echo esc_html__('404 error', 'appdown'); ?></li>
    <?php
    }
    elseif (is_archive()) {
        $archive_year   = get_the_time('Y');
        $archive_month  = get_the_time('m');
        $archive_day    = get_the_time('d');
        ?>
        <li class="breadcrumb-item">
        <a href="<?php echo esc_url(home_url('/')); ?>"> <?php esc_html_e('Home', 'appdown'); ?> </a>
       </li>
       <li class="breadcrumb-item active">
        <a href="<?php echo get_day_link( $archive_year, $archive_month, $archive_day); ?>"> <?php echo get_the_archive_title(); ?> </a></li>
    <?php
    }
    elseif (is_tag()) {single_tag_title();}
    elseif (is_day()) { esc_html__('Archive for', 'appdown'); the_time(get_option('date_format'));}
    elseif (is_month()) { esc_html__('Archive for', 'appdown'); the_time('F, Y');}
    elseif (is_year()) { esc_html__('Archive for', 'appdown'); the_time('Y');}
    elseif (isset($_GET['paged']) && !empty($_GET['paged'])) {echo "<li>".esc_html__('Blog Archives', 'appdown');}
    elseif (is_search()) {
        ?>
        <li class="breadcrumb-item">
       <?php  echo '<a href="';
        echo esc_url(home_url('/')).'">';
        ?>
        <?php 
        echo esc_html__('Home', 'appdown');
        echo "</a></li>";
        ?>  
        <li class="breadcrumb-item active">
       <?php 
        echo esc_html__('Search Results', 'appdown');
    }
    echo '<li></ol>';

}