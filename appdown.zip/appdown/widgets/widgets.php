<?php 

// Register Widget areas
add_action('widgets_init', function() {

    register_sidebar(array(
        'name'          => esc_html__('Sidebar','appdown'),
        'description'   => esc_html__('Add widgets here for default sidebar area','appdown'),
        'id'            => 'sidebar_widgets',
        'before_widget' => '<div id="%1$s" class="%2$s widget default_widget  row m0 apps_categories ">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ));


// wow fadeInUp

});
// Register Widgets
add_action('widgets_init', function() {
    register_widget('appdown_Categories');
    register_widget('Bdt_Popular_Posts');
    register_widget('Appdown_Popular_Posts');

});
// Require widget files
require get_template_directory() . '/widgets/categories.php';
require get_template_directory() . '/widgets/popular-download.php';
require get_template_directory() . '/widgets/popular-post.php';





