<?php

class Bdt_Popular_Posts extends WP_Widget {
    
    function __construct()  {
        parent::__construct('popular_download', esc_html__('(Theme) Popular Download', 'appdown'), array(
            'classname' => 'popular-post-widget',
            'description' => esc_html__('Displays popular posts with thumbnail.','appdown')
        ));
    }


    
    function widget($args, $instance)
    {
        extract($args);
        $title = apply_filters('widget_title', $instance['title']);
        $number = $instance['number'];
        $orderby = $instance['orderby'];

        if(!$orderby) {
            $orderby = 'Highest Comments';
        }
        echo $args['before_widget'];
        ?>
            <?php
            if($title) {
                echo $args['before_title'] . $title .$args['after_title'];
            }
            ?>
        <?php

        if($orderby == 'Highest Comments') {
            $order_string = '&orderby=comment_count';
        } else {
            $order_string = '&key=views&orderby=meta_value_num';
        }
        $popular_posts = new WP_Query(esc_sql( $order_string.'&order=DESC'.'&ignore_sticky_posts=1&posts_per_page='.$number));
        
        if($popular_posts->have_posts()):
        ?>      
         <div class="row m0 popular_download wow fadeInLeft">
           <!--  <div class="heading">
             <h3>Popular Download</h3>
            </div> -->
            <div class="popular_items">
        <?php while($popular_posts->have_posts()): $popular_posts->the_post(); 
        if(has_post_thumbnail()):
             $app_free = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_free') : '';

            ?>
            <!-- Item -->
    

            <div class="media single_item">

                 <?php the_post_thumbnail( 'bdt_28x28', array('class'=>'d-flex align-self-center mr-3'), true ); ?> 
                <div class="media-body item_details">
                    <h5 class="mt-0">
                         <?php echo wp_trim_words( get_the_title(),3); ?>
                    </h5>
                    <a href="<?php the_permalink(); ?>"><?php echo esc_html($app_free); ?></a>
                </div>
            </div>                
        <?php endif; ?>
        <?php endwhile; ?>          
        <?php endif; ?>
        <?php wp_reset_postdata(); ?>
            </div>
        </div>
        <?php
        echo $args['after_widget'];
    }
    
    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['number'] = $new_instance['number'];
        $instance['orderby'] = $new_instance['orderby'];
        return $instance;
    }

    function form($instance) {
        $defaults = array('title' => esc_html__('Popular Posts','appdown'), 'number' => 4, 'orderby' => 'Highest Comments');
        $instance = wp_parse_args((array) $instance, $defaults); ?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:','appdown') ?></label>
            <input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" value="<?php echo esc_attr($instance['title']); ?>" />
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('orderby')); ?>"><?php esc_html_e('Popular Posts Order By:','appdown') ?></label>
            <select id="<?php echo esc_attr($this->get_field_id('orderby')); ?>" name="<?php echo esc_attr($this->get_field_name('orderby')); ?>" class="widefat" style="width:100%;">
                <option <?php if ($instance['orderby'] == 'Highest Comments') echo 'selected="selected"'; ?>><?php esc_html_e('Highest Comments','appdown') ?></option>
                <option <?php if ($instance['orderby'] == 'Highest Views') echo 'selected="selected"'; ?>><?php esc_html_e('Highest Views','appdown') ?></option>
            </select>
        </p>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Number of items to show:','appdown') ?></label>
            <input type="text" class="tiny-text" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" value="<?php echo esc_attr($instance['number']); ?>" />
        </p>

    <?php
    }
}
?>