<?php

class Appdown_Popular_Posts extends WP_Widget {
	
	function __construct()	{
        parent::__construct('popular_posts', esc_html__('(appdown) popular posts','appdown'), array(
            'classname' => 'popular-widget',
            'description' => esc_html__('Displays popular posts with thumbnail.','appdown')
        ));
	}
	function widget($args, $instance)
	{
		$title             = isset($instance['title']) ? esc_html($instance['title']) : esc_html__('Popular', 'appdown');
        $post_number       = isset($instance['post_number']) ? esc_html($instance['post_number']) : '3';
        $post_category     = isset($instance['post_category']) ? esc_html($instance['post_category']) : ''; 
        $post_categorys     = isset($instance['post_categorys']) ? esc_html($instance['post_categorys']) : ''; 
       $orderby = isset($instance['orderby'])? esc_html($instance['orderby']) : ''; 
        
     
        if ( $title ) {
            echo $args['before_title'] . $title . $args['after_title'];
        }
        
        $featured_news = new WP_Query(array(
            'post_type' => 'post',
            'posts_per_page' => $post_number,
            'category_name' => $post_category,
        ));  

        $other_news = new WP_Query(array(
            'post_type' => 'post',
            'posts_per_page' => $post_number,
            'category_name' => $post_categorys,
        ));
			
        $order_string = '&key=views&orderby=meta_value_num';

         $popular_posts = new WP_Query(esc_sql( $order_string.'&order=DESC'.'&ignore_sticky_posts=1&posts_per_page='.$post_number));

		?>		
		
		

 <div class="row m0 quick_apps sidebar_inner wow fadeInUp">
                <ul class="nav nav-pills nav-justified" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#popular" role="tab"><?php echo esc_html('popular','appdown');?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#<?php echo $post_category?>" role="tab"><?php echo $post_category?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#<?php echo  $post_categorys?>" role="tab"><?php echo  $post_categorys?></a>
                    </li>
                </ul>

        <!-- Tab panes -->
        <div class="tab-content">
            
            <div class="tab-pane" id="popular" role="tabpanel">
            
              <?php 

             if($popular_posts->have_posts()):
              while($popular_posts->have_posts()): $popular_posts->the_post(); 
                 if(has_post_thumbnail()):
            $app_free = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_free') : '';
            $app_version = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_version') : '';
            ?>
              
                <div class="row single_apps">
                    <div class="align-self-start apps_img">

                        <?php the_post_thumbnail('bdt_68x68'); ?>
                    </div>
                    <div class="single_apps_inner">
                        <a href="<?php the_permalink();?>" class="apps_title"> <?php echo wp_trim_words( get_the_title(),6); ?></a>
                        <div class="apps_version"><?php echo esc_html($app_version,'appdown');?></div>
                        <div class="rating_area">
                            <div class="rate-container">
                      
                                <?php global  $post;?>
                                 <?php bdt_avg_star_rating('post', $post->ID);?>
                            </div>
                        </div>
                    </div>
                    <a href="#" class="base_button hover_style"><?php echo esc_html($app_free); ?></a>
                </div>
                <?php endif; endwhile;endif; ?>

               
            </div>
            <div class="tab-pane active" id="<?php echo $post_category?>" role="tabpanel">
                 
           <?php while($featured_news->have_posts()): $featured_news->the_post(); 
            $app_free = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_free') : '';
            $app_version = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_version') : '';
                 ?>
                <div class="row single_apps">
                    <div class="align-self-start apps_img">
                 
                        <a href="<?php the_permalink(); ?>" rel="bookmark">
                         <?php the_post_thumbnail('bdt_68x68'); ?>

                         </a>
                    </div>
                    <div class="single_apps_inner">
                        <a href="<?php the_permalink(); ?>" class="apps_title" title="<?php the_title(); ?>">
                          <?php echo wp_trim_words( get_the_title(), 15); ?>
                           </a>
                        <div class="apps_version"><?php echo esc_html($app_version,'appdown');?></div>
                        <div class="rating_area">
                            <div class="rate-container">
                               
                                  <?php bdt_avg_star_rating('post', $post->ID);?>
                            </div>
                        </div>
                    </div>
                    <a href="#" class="base_button hover_style"><?php echo esc_html($app_free); ?></a>
                </div>
                  
              <?php
             endwhile; ?>
            
            </div>

            <div class="tab-pane" id="<?php echo $post_categorys?>" role="tabpanel">
                <?php while($other_news->have_posts()): $other_news->the_post(); 
                  $app_free = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_free') : '';
                  $app_version = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_version') : '';
                ?>
             
                <div class="row single_apps">
                    <div class="align-self-start apps_img">
                      
                         <a href="<?php the_permalink(); ?>" rel="bookmark">
                         <?php the_post_thumbnail('bdt_68x68'); ?>
                         </a>
                    </div>
                    <div class="single_apps_inner">
                        <a href="details.html" class="apps_title"> 
                          <?php echo wp_trim_words( get_the_title(), 7); ?>
                            
                        </a>
                        <div class="apps_version"><?php echo esc_html($app_version,'appdown');?></div>
                        <div class="rating_area">
                            <div class="rate-container">
                           
                                  <?php bdt_avg_star_rating('post', $post->ID);?>
                            </div>
                        </div>
                    </div>
                    <a href="#" class="base_button hover_style"><?php echo esc_html($app_free); ?></a>
                </div>
                 <?php endwhile;?>

             
            </div>
        </div>
    </div>
		<?php 
	}  
	 public function form($instance){
        $title             = isset($instance['title']) ? esc_html($instance['title']) : esc_html__('Popular', 'appdown');
        
        $post_number       = isset($instance['post_number']) ? esc_html($instance['post_number']) : '3';
        
        $post_category     = isset($instance['post_category']) ? esc_html($instance['post_category']) : '';  
        $post_categorys     = isset($instance['post_categorys']) ? esc_html($instance['post_categorys']) : ''; 
        
        ?>
        <table style="width:100%">
            <!--Title-->
            <tr>
                <th style="text-align: left"> <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title','appdown') ?></label> </th>
            </tr>
            <tr>
                <td>
                    <input type="text" id="<?php echo esc_attr($this->get_field_id('title')); ?>" class="widefat foot_logo_url" name="<?php echo esc_attr($this->get_field_name('title')); ?>" value="<?php echo esc_attr($title); ?>"/>
                </td>
            </tr>
            <!--Post Per Page-->
            <tr>
                <th style="text-align: left"> <label for="<?php echo esc_attr($this->get_field_id('post_number')); ?>"><?php esc_html_e('Posts per page', 'appdown') ?></label> </th>
            </tr>
            <tr>
                <td>
                    <input type="text" id="<?php echo esc_attr($this->get_field_id('post_number')); ?>" class="widefat foot_logo_url" name="<?php echo esc_attr($this->get_field_name('post_number')); ?>" value="<?php echo esc_attr($post_number); ?>"/>
                </td>
            </tr>

            <tr>
                <td>
                     <select id="<?php echo $this->get_field_id('post_category '); ?>" name="<?php echo $this->get_field_name('post_category'); ?>" class="widefat" style="width:100%;">
                        
            <?php foreach(get_terms('category','parent=0&hide_empty=0') as $term) { ?>
            <option <?php selected( $instance['post_category'], $term->name ); ?> value="<?php echo $term->name; ?>"><?php echo $term->name; ?></option>
            <?php } ?>      
        </select>
                </td>

            </tr>
            <tr>
        <td>
        <select id="<?php echo $this->get_field_id('post_categorys '); ?>" name="<?php echo $this->get_field_name('post_categorys'); ?>" class="widefat" style="width:100%;">
                        
            <?php foreach(get_terms('category','parent=0&hide_empty=0') as $terms) { ?>
            <option <?php selected( $instance['post_categorys'], $terms->name ); ?> value="<?php echo $terms->name; ?>"><?php echo $terms->name; ?></option>
            <?php } ?>      
        </select>
                    
       </td>

            </tr>
            <tr><td>Add a category slug here. If you want to add one or more please use (+) sign. <br/> <br/></td></tr>

        </table>
    <?php
    }
    public function update($new_instance, $old_instance){
        $instance                          = $old_instance;
        $instance['title']                 = $new_instance['title'];

        $instance['post_number']           = $new_instance['post_number'];
        
        $instance['post_category']         = $new_instance['post_category'];
        $instance['post_categorys']         = $new_instance['post_categorys'];
        return $instance;

    }
}