<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package Appdown
 */

get_header(); ?>

     <!--========== Appstore Area ==========-->
        <section class="appstore_area">
            <div class="container">
                <div class="row appstore_inner container_section">
                    <div class="col-lg-4">
                        <div id="sidebar"> 
                            <!--========== Download Part ==========-->
                            <?php get_sidebar(); ?>
                        </div>
                        
                    </div>
                    
                    <div class="col-lg-8">
                        <div id="content">
                            <div class="row m0 blog_area wow fadeInDown">
                               <?php
                        while(have_posts()) : the_post();
                            get_template_part( 'template-parts/content', get_post_format() );
                        endwhile;
                    ?>
                            </div>
                   
               
                            <div class="row m0 pagination_part">
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination justify-content-center">
 
                                    <div class="text-center">
                                    <?php 
                                        $appdown_pagination = get_the_posts_pagination(array(
                                            'mid_size'  => 2,
                                            'prev_text' => '<i class="fa fa-chevron-left"></i><span class="span_link">'.esc_html__('Previous', 'appdown').'</span>',
                                            'next_text' => '<span class="span_link_right">'.esc_html__('Next', 'appdown') .'</span><i class="fa fa-chevron-right"></i>',
                                            'screen_reader_text' => ' ',
                                        ) );
                                        echo $appdown_pagination;
                                    ?>
                                    </div>

                                    </ul>
               
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--========== End Appstore Area ==========-->

<?php

get_footer();
