<?php
/**
 * The template for displaying comments
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package appdown
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>
<div id="comments" class="comments-container">
	<?php
	// You can start editing here -- including this comment!
	if ( have_comments() ) : ?>

    <div class="headline">  
	 <h3>
		<?php comments_number( ' ', 'Comment(1)', 'Comments(%)' ); ?>
	</h3>
    </div>

	<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : // Are there comments to navigate through? ?>
	<nav id="comment-nav-above" class="navigation comment-navigation" role="navigation">
		
		<div class="nav-links">
			<div class="nav-previous"> <?php previous_comments_link( esc_html__( 'Older Comments','appdown') ); ?> </div>
			<div class="nav-next"> <?php next_comments_link( esc_html__('Newer Comments', 'appdown') ); ?> </div>
		</div><!-- .nav-links -->
	</nav><!-- #comment-nav-above -->
	<?php endif; // Check for comment navigation. ?>


<div class="row perfect_cond comments_area">
        <?php
            wp_list_comments( array(
                'style'      => 'ul',
                'short_ping' => true,
                'callback'	 => 'resuma_comments'
            ) );
        ?>
    </div><!-- .comment-list -->
        <?php
 

	endif; 


	// If comments are closed and there are comments, let's leave a little note, shall we?
	if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
		<p class="no-comments"> <?php esc_html_e( 'Comments are closed.','appdown'); ?> </p>
	    <?php
	endif;
	?>

</div>


<?php if( have_comments() ) : ?>
<div class="separator"></div>
<?php endif; ?>
	<!-- Comment Form -->
<div class="row perfect_cond comments_area">
	     <div class="headline">
          <h3><?php esc_html_e('Leave a Comment','appdown'); ?></h3>
         </div>


	<?php
	$commenter      = wp_get_current_commenter();
	$req            = get_option( 'require_name_email' );
	$aria_req       = ( $req ? " aria-required='true'" : '' );

	$fields =  array(
		'author' => ' <div class="row address_form"><div class="col-md-6"><input type="text" name="author" id="name" class="form-control" value="' . esc_attr( $commenter['comment_author'] ) . '" placeholder="'.esc_attr__('Your Name *','appdown').'"'. $aria_req .'></div>',
		'email'	=> '    <div class="col-md-6"><input type="email" name="email" id="email" class="form-control" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" placeholder="'.esc_attr__('Enter Your Email *', 'appdown').'"'. $aria_req .'></div></div>',
	);

	$comments_args = array(
		'fields'                => apply_filters( 'comment_form_default_fields', $fields ),
		'class_form'            => 'request_form row perfect_cond',
		'submit_button'         => '<button class="hover_style">'.esc_html('Submit', 'appdown').'</button>',
		'title_reply'           => '',
		'comment_notes_before'  => '',
		'comment_field'         => '<textarea class="form-control" id="comment" name="comment" placeholder="'.esc_attr__('Write a comment *', 'appdown') .'" rows="5"></textarea>',
		'comment_notes_after'   => '',
	);

	comment_form($comments_args);

    ?>
</div>



