<?php
/**
 * Template Name: contact
 */
get_header();
$map_api_key    = defined('FW') ? fw_get_db_settings_option('map_api') : '';
$cf7_title      = defined('FW') ? fw_get_db_settings_option('cf7_title') : '';
$map_address      = defined('FW') ? fw_get_db_settings_option('contact_details') : '';


$apps_version     = defined('FW') ? fw_get_db_settings_option('apps_version') : '';
$apps_short_note     = defined('FW') ? fw_get_db_settings_option('apps_short_note') : '';
$apps_logo= defined('FW') ? fw_get_db_settings_option('apps_logo') : '';
$apps_logo=isset($apps_logo ['url']) ? $apps_logo ['url'] : '';
$upload_theme_apps= defined('FW') ? fw_get_db_settings_option('upload_theme_apps') : '';
$upload_theme_apps=isset($upload_theme_apps ['url']) ? $upload_theme_apps ['url'] : '';

?>

        
        <!--========== Appstore Area ==========-->
        <section class="appstore_area">
            <div class="container">
                <div class="row appstore_inner">
                    <div class="col-md-4">
                        <!--========== Download Part ==========-->
                  
                          <?php get_sidebar(); ?>
                        <!--========== End Download Part ==========-->
                    </div>
                    
                    <div class="col-md-8">
                        <!--==== Google Maps ===-->
                        
                            <div class="row m0 map_area">
                           

                       <?php     
                       $address = $map_address;
                      echo '<iframe frameborder="0" src="https://maps.google.com/maps?f=q&source=s_q&hl=en&geocode=&q=' . str_replace(",", "", str_replace(" ", "+", $address)) . '&z=14&output=embed" width="100%" height="400"></iframe>';?>

                            </div>
                        <!--==== Comments Area ===-->
                        <div class="row perfect_cond comments_area">
                            <div class="headline">
                                <h3><?php echo esc_html($cf7_title); ?></h3>
                            </div>
                            <div class="row m0 request_form">
                                 <?php
                    $cf7_shortcode  = defined('FW') ? fw_get_db_settings_option('cf7_shortcode') : '';
                    if(!empty($cf7_shortcode)) {
                        echo do_shortcode($cf7_shortcode);
                    }
                    ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--========== End Appstore Area ==========-->
        
        
<?php
  

get_footer();