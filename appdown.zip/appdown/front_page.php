<?php
/**
 * Template Name: home
 */
get_header();


$cats_one=fw_get_db_settings_option( 'cat' );
$cats_two=fw_get_db_settings_option( 'cats' );  
$cats_three=fw_get_db_settings_option( 'cats_three' );  
$cats_four=fw_get_db_settings_option( 'cats_four' );  
$cats_five=fw_get_db_settings_option( 'cats_five' );  
$cats_six=fw_get_db_settings_option( 'cats_six' ); 

?>
     <!--========== Slider area ==========-->
        <section class="slider_area">
            <div class="container">
                <div class="row m0 slider_inner">
                    <div class="camera_wrap camera_azure_skin" id="slider_part">                         
<?php      
 // Slider 
$hospitalbd_slider = new WP_Query(array(
'post_type' => 'gallery',
'posts_per_page'    => -1,
));
?> 
 <?php while ($hospitalbd_slider->have_posts()) : 
                      $hospitalbd_slider->the_post(); 
$bg_image  = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'bg_image'): '';
$bg_image = isset($bg_image ['url']) ? $bg_image['url'] : '';
$g_item_sub   = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'g_item_sub'): '';
$g_item_sub   = isset($g_item_sub ['url']) ? $g_item_sub  ['url'] : '';
$g_item_column   = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'g_item_column'): '';
$g_item_column  = isset($g_item_column ['url']) ? $g_item_column ['url'] : '';
$tour_gallery   = defined('FW') ? fw_get_db_post_option(get_the_ID(), 's_main_title'): '';
$s_sub_title   = defined('FW') ? fw_get_db_post_option(get_the_ID(), 's_sub_title'): '';
$s_discription   = defined('FW') ? fw_get_db_post_option(get_the_ID(), 's_discription'): '';
// app link
$g_item_app  = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'g_item_app'): '';
$g_item_app = isset($g_item_app['url']) ? $g_item_app ['url'] : '';
$app_sotre_image  = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_sotre_image'): '';
$app_sotre_image = isset($app_sotre_image['url']) ? $app_sotre_image ['url'] : '';
$play_store_image  = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'play_store_image'): '';
$play_store_image = isset($play_store_image['url']) ? $play_store_image ['url'] : '';
$app_sotre_link  = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_sotre'): '';
$play_store_link  = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'play_store'): '';
?>
                       <?php if(!empty($bg_image)){?>
                     <div data-thumb="<?php echo $bg_image ; ?>" data-src="<?php  echo $bg_image ; ?>">
                            <div class="camera_caption fadeFromLeft">
                                <?php if(!empty($tour_gallery)){?>
                                <h2> <?php  echo esc_html($tour_gallery); ?> </h2>
                                <?php }if(!empty($s_sub_title)){?>
                                <h3><?php echo esc_html($s_sub_title);?></h3>
                                <?php } if(!empty($s_discription)){?>
                                <p><?php echo esc_html($s_discription);?></p>
                                <?php } if(!empty($app_sotre_image)&& !empty($play_store_image)){?>
                                
                                <div class="google_link">
                                    <a href="<?php echo esc_url($app_sotre_link);?>"><img src="<?php echo esc_url($app_sotre_image);?>" alt="appstore"></a>
                                    <a href="<?php echo esc_url($play_store_link);?>"><img src="<?php echo esc_url($play_store_image);?>" alt="appstore"></a>
                                </div>
                                <?php }?>
                                <a href="<?php echo esc_url($g_item_app) ;?>" class="base_button hover_style" download><?php echo esc_html('Download now','appdown')?></a>
                                <div class="mob_img fadeFromBottom">
                                    <img src="<?php echo esc_url($g_item_column) ;?>" alt="android Img">
                                    <img src="<?php echo esc_url($g_item_sub) ;?>" alt="android Img">
                                </div>
                            </div>
                        </div>
                        
                       <?php } endwhile; ?>

                  
                    </div><!-- #camera_wrap_1 -->
                </div>
            </div>
        </section>   
        <!--========== End Slider area ==========-->
        <?php 
       $left_banner_title=fw_get_db_settings_option('banner_title');
       $left_offer_title=fw_get_db_settings_option('offer_title' );
       $left_button_link=fw_get_db_settings_option('button_link' );
       $left_banner_images=fw_get_db_settings_option( 'banner_image' );
       $left_banner_images = isset($left_banner_images['url']) ? $left_banner_images ['url'] : '';
       $right_banner_title=fw_get_db_settings_option( 'banner_right_title' );
       $right_offer_title=fw_get_db_settings_option( 'offer_right_title' );
       $right_banner_link=fw_get_db_settings_option( 'button_right_link' );
       $right_banner_image=fw_get_db_settings_option( 'banner_right_image' );
       $right_banner_image = isset($right_banner_image['url']) ? $right_banner_image ['url'] : '';
        ?>
        <!--========== Banner Area ==========-->
        <section class="banner_area">
            <div class="container">
                <div class="row banner">
                    <div class="col-md-6">
                        <div class="card card-inverse">
                         <?php  if(!empty($left_banner_images)){?>
                        
                            <img class="card-img" src="<?php echo esc_url($left_banner_images ); ?>" alt="Card image">
                            <?php }?>
                            <div class="card-img-overlay">
                                <?php if(!empty($left_banner_title)){ ?>
                                <h4 class="card-title"><?php echo esc_html($left_banner_title);?></h4>
                                <?php } if(!empty($left_offer_title)){?>
                                <p class="card-text"><?php echo esc_html($left_offer_title);?></p>
                                <?php } if(!empty($left_button_link)){?>
                                <a href="<?php echo esc_url($left_button_link); ?>" class="base_button hover_style"><?php echo esc_html('FREE DOWNLOAD','appdown')?></a>
                                <?php }?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card card-inverse">
                            <?php if(!empty($right_banner_image)){?>
                            <img class="card-img" src="<?php echo esc_url($right_banner_image); ?>" alt="Card image">
                            <?php }?>
                            <div class="card-img-overlay">
                                <?php if(!empty($right_banner_title)){?>
                                <h4 class="card-title"><?php echo esc_html($right_banner_title);?></h4>
                                <?php } if(!empty($right_offer_title)){?>
                                <p class="card-text"><?php echo esc_html($right_offer_title);?></p>
                                <?php } if(!empty($right_offer_title)){?>
                                <a href="<?php echo esc_url($right_banner_link);?>" class="base_button hover_style"><?php echo esc_html('FREE DOWNLOAD','appdown')?></a>
                                <?php }?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--========== End Banner Area ==========-->
        
        <!--========== Appstore Area ==========-->
        <section class="appstore_area">
            <div class="container">
                <div class="row appstore_inner container_section">
                    <div class="col-md-4">
                        <div id="sidebar">
                            <!--========== Download Part ==========-->
 
                            <?php get_sidebar(); ?>
                            <!-- ========== End Quick Apps ========== -->
                        </div>
                    </div>
                    
                    <div class="col-md-8">
                        <div id="content">
                            <div class="row appdown_apps wow fadeInUp">
                                <div class="row m0 headline">
                                    <?php   $category_id = get_cat_ID($cats_one);
                                   $category_link = get_category_link( $category_id );?>
                                    <h3> <?php  echo esc_html($cats_one);?></h3>
                                    <a href="<?php  echo esc_url($category_link);?>" class="base_button hover_style"><?php echo esc_html('see more','appdown');?></a>
                                </div>
                                <div class="row m0 apps_store">
                             <?php
                              $cat_position_one = new WP_Query(array(
                                'post_type'         => 'post',
                                'posts_per_page'    => -1,
                                'include' => fw_get_db_settings_option('cat'),
                                'category_name'=>$cats_one,
                                ));
                    while($cat_position_one->have_posts()) : $cat_position_one->the_post();
                      $app_free = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_free') : '';  
                           ?>
                                    <div class="col-xl-4 col-lg-6 col-md-12 col-sm-6">
                                        <div class="media single_apps">

                                            <?php the_post_thumbnail('bdt_68x68',array('class'=>'d-flex mr-3')); ?>
                                            <div class="media-body single_apps_inner">
                                                <a href="<?php the_permalink(); ?>" class="apps-title"><?php  echo wp_trim_words( get_the_title(),3);?></a>
                                                <a href="<?php the_permalink(); ?>" class="base_button hover_style"><?php echo $app_free ; ?></a>
                                                <?php do_action('wpr_after_post_title'); ?>
                                                <div class="rating_area">
                                                    <div class="rate-container">
                                                       
                                                        <?php bdt_avg_star_rating('post', $post->ID); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                <?php         
                        endwhile;
                        ?>
                                    
                                </div>
                            </div>
                            <div class="row appdown_apps wow fadeInDown">
                                <div class="row m0 headline">
                                   <?php   $category_id = get_cat_ID($cats_two);
                                   $category_link = get_category_link( $category_id );?>
                                    <h3><?php echo esc_html($cats_two); ?> </h3>
                                    <a href="<?php echo esc_url($category_link) ;?>" class="base_button hover_style"><?php echo esc_html('see more');?></a>
                                </div>
                                <div class="row m0 apps_store">
                              <?php
                              $cat_position_two = new WP_Query(array(
                                'post_type'         => 'post',
                                'posts_per_page'    => -1,
                                'include' => fw_get_db_settings_option('cats'),
                                'category_name'=>$cats_two,
             
                                ));
                        while($cat_position_two->have_posts()) : $cat_position_two->the_post();
                    $app_free = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_free') : '';
                            ?>
                                    <div class="col-xl-4 col-lg-6 col-md-12 col-sm-6">
                                        <div class="media single_apps">
                                           
                                              <?php the_post_thumbnail('bdt_68x68',array('class'=>'d-flex mr-3')); ?>
                                            <div class="media-body single_apps_inner">
                                                <a href="<?php the_permalink(); ?>" class="apps-title"><?php  echo wp_trim_words( get_the_title(),3);?></a>
                                                <a href="<?php the_permalink(); ?>" class="base_button hover_style"><?php echo $app_free;?></a>
                                                <div class="rating_area">
                                                    <div class="rate-container">
                                                 
                                                        <?php bdt_avg_star_rating('post', $post->ID); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                   <?php 
                                    endwhile;
                                   ?>

                                </div>
                            </div>
                            <div class="row appdown_apps wow fadeInUp">
                                <div class="row m0 headline">
                                     
                                  <?php  $category_id = get_cat_ID($cats_three);
                                   $category_link = get_category_link( $category_id );?>
                                    <h3><?php echo esc_html($cats_three); ?> </h3>
                                    <a href="<?php echo esc_url($category_link);?>" class="base_button hover_style"><?php echo esc_html('see more','appdown');?></a>
                                </div>
                                <div class="row m0 apps_store">

                            <?php
                              $cat_position_three= new WP_Query(array(
                                'post_type'         => 'post',
                                'posts_per_page'    => -1,
                                'include' => fw_get_db_settings_option('cats_three'),
                                'category_name'=>$cats_three,
            
             
                                ));
                        while($cat_position_three->have_posts()) : $cat_position_three->the_post();
                         $app_free = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_free') : '';
                            ?>
                                    <div class="col-xl-4 col-lg-6 col-md-12 col-sm-6">
                                        <div class="media single_apps">
                                          
                                              <?php the_post_thumbnail('bdt_68x68',array('class'=>'d-flex mr-3')); ?>
                                            <div class="media-body single_apps_inner">
                                                <a href="<?php the_permalink(); ?>" class="apps-title"><?php  echo wp_trim_words( get_the_title(),3);?></a>
                                                <a href="<?php the_permalink(); ?>" class="base_button hover_style"><?php echo $app_free;?></a>
                                                <div class="rating_area">
                                                    <div class="rate-container"> 
                                                        <?php bdt_avg_star_rating('post', $post->ID); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                 
                                 <?php endwhile;?>
                                </div>
                            </div>
                            <div class="row appdown_apps wow fadeInDown">
                                <div class="row m0 headline">
                                 <?php  $category_id = get_cat_ID($cats_four);
                                   $category_link = get_category_link( $category_id );?>
                                    <h3><?php echo esc_html($cats_four);?></h3>
                                    <a href="<?php echo esc_url($category_link);?>" class="base_button hover_style"><?php echo esc_html('see more','appdown')?></a>
                                </div>
                                <div class="row m0 apps_store">
                            <?php
                              $cat_position_four = new WP_Query(array(
                                'post_type'         => 'post',
                                'posts_per_page'    => -1,
                                'include' => fw_get_db_settings_option('cats_four'),
                                'category_name'=>$cats_four,
             
                                ));
                        while($cat_position_four->have_posts()) : $cat_position_four->the_post();
                          $app_free = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_free') : '';
                            ?>
                                    <div class="col-xl-4 col-lg-6 col-md-12 col-sm-6">
                                        <div class="media single_apps">
                                          
                                              <?php the_post_thumbnail('bdt_68x68',array('class'=>'d-flex mr-3')); ?>
                                            <div class="media-body single_apps_inner">
                                                <a href="<?php the_permalink(); ?>" class="apps-title"><?php  echo wp_trim_words( get_the_title(),3);?></a>
                                                <a href="<?php the_permalink(); ?>" class="base_button hover_style"><?php echo $app_free ;?></a>
                                                <div class="rating_area">
                                                    <div class="rate-container">
                                                 
                                                        <?php bdt_avg_star_rating('post', $post->ID); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                 
                                 
                                  <?php endwhile;?>
                                   
                                </div>
                            </div>
                            <div class="row appdown_apps wow fadeInUp">
                                <div class="row m0 headline">
                                 <?php  $category_id = get_cat_ID($cats_five);
                                   $category_link = get_category_link( $category_id );?>
                                    <h3><?php echo esc_html($cats_five);?></h3>
                                    <a href="<?php echo esc_url($category_link);?>" class="base_button hover_style"><?php echo esc_html('see more','appdown');?></a>
                                </div>
                                <div class="row m0 apps_store">
                            <?php
                              $cat_position_five = new WP_Query(array(
                                'post_type'         => 'post',
                                'posts_per_page'    => -1,
                                  'include' => fw_get_db_settings_option('cats_five'),
                                'category_name'=>$cats_five,
             
                                ));
                        while($cat_position_five->have_posts()) : $cat_position_five->the_post();
                        $app_free = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_free') : '';
                            ?>
                                    <div class="col-xl-4 col-lg-6 col-md-12 col-sm-6">
                                        <div class="media single_apps">
                                      
                                             <?php the_post_thumbnail('bdt_68x68',array('class'=>'d-flex mr-3')); ?>
                                            <div class="media-body single_apps_inner">
                                                <a href="<?php the_permalink(); ?>" class="apps-title"><?php  echo wp_trim_words( get_the_title(),3);?></a>
                                                <a href="<?php the_permalink(); ?>" class="base_button hover_style"><?php  echo esc_html($app_free);?></a>
                                                <div class="rating_area">
                                                    <div class="rate-container">
                                                   
                                                        <?php bdt_avg_star_rating('post', $post->ID); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile;?>
                                </div>
                            </div>
                            <div class="row appdown_apps wow fadeInDown">
                                <div class="row m0 headline">
                                     <?php  $category_id = get_cat_ID($cats_six);
                                   $category_link = get_category_link( $category_id );?>
                                    <h3><?php echo esc_html($cats_six);?></h3>
                                    <a href="<?php echo esc_url($category_link);?>" class="base_button hover_style"><?php echo esc_html('see more','appdown');?></a>
                                </div>
                                <div class="row m0 apps_store">
                                 
                                  <?php
                              $cats_position_six = new WP_Query(array(
                                'post_type'         => 'post',
                                'posts_per_page'    => -1,
                                'include' => fw_get_db_settings_option('cats_six'),
                                'category_name'=>$cats_six,
            
             
                                ));?>
                               <?php while($cats_position_six->have_posts()) : $cats_position_six->the_post();
                                $app_free = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_free') : '';

                               ?>
                                    <div class="col-xl-4 col-lg-6 col-md-12 col-sm-6">
                                        <div class="media single_apps">

                                             <?php the_post_thumbnail('bdt_68x68',array('class'=>'d-flex mr-3')); ?>
                                            <div class="media-body single_apps_inner">
                                                <a href="<?php the_permalink(); ?>" class="apps-title"><?php echo wp_trim_words( get_the_title(),3);?></a>
                                                <a href="<?php the_permalink(); ?>" class="base_button hover_style">
                                                    <?php echo  $app_free;?>
                                                </a>
                                                <div class="rating_area">
                                                    <div class="rate-container">
                                            <?php bdt_avg_star_rating('post', $post->ID); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile;?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

<?php 
get_footer();






