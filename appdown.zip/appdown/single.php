<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Appdown
 */

get_header(); 
$tour_gallery   = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'tour_gallery'): '';
?>
<!--========== Appstore Area ==========-->
<?php    
   if (!empty($tour_gallery )) {
        
    get_template_part( 'template-parts/single', get_post_format() );
   }else{
    ?>

        <section class="appstore_area">
            <div class="container">
                <div class="row appstore_inner container_section">
                    <div class="col-md-4">
                        <div id="sidebar">
                           <!--========== Download Part ==========-->
                              <?php get_sidebar(); ?>
                            <!-- ========== End Quick Apps ========== -->
                        </div>
                    </div>
                    
                    <div class="col-md-8">
                        <div id="content">
                            <!--==== Blog Details ===-->
                            <div class="row m0 blog_area wow fadeInDown">
                                <div class="blog_details">
                                    <?php
                                      while (have_posts()) : the_post();
                                      $app_free = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_free') : '';  
                                        $cats = get_the_terms(get_the_ID(), 'category');
                                       $cat  = is_array($cats) ? $cats[0]->name : '';
                                       $cat_link  = is_array($cats) ? get_category_link($cats[0]->term_id) : '';
                                      
                                      ?>
                                    <div class="single_blog">
                                        <h2><?php the_title();?></h2>
                                        <ul class="nav post_author">
                                            <li class="nav-item"><?php echo esc_html('Post By : ','appdown');?><?php echo get_the_author_meta('display_name'); ?></li>
                                            <li class="nav-item"><?php echo esc_html('Date :','appdown')?><?php the_time('M d, Y'); ?></li>  
                                        </ul>
                                        
                                    <?php the_post_thumbnail(); ?>
                                       
                                                 <?php the_content();?>
                                        <div class="row m0 social_area">
                                            <div class="col-md-6">
                                                <div class="social_apps">
                                                    <ul class="nav">
                                                        
                                               <?php if(has_tag()) : ?>
        									   <?php
        									   $tags = get_the_tags(get_the_ID());
        									   foreach($tags as $tag){?>
                                                        <li class="nav-item">
                                                <?php                         
                                                    echo '<a href="'.get_tag_link($tag->term_id).'" rel="tag" class="nav-link">'.$tag->name.'</a>';
            									    } ?>
            									<?php endif; ?>                
                                                        </li>
                                                      
                                                    </ul>
								
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="social_icon">
                                                    <ul class="nav justify-content-end">
                                                        
                                                              
                                                        <li class="nav-item">
                                                            <a href="https://facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" class="nav-link fb-icon">
                                                                <i class="fa fa-facebook"></i>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="https://twitter.com/intent/tweet?text=<?php the_permalink(); ?>" class="nav-link ttr-icon">
                                                                <i class="fa fa-twitter"></i>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="https://plus.google.com/share?url=<?php the_permalink() ?>" class="nav-link gplus-icon">
                                                                <i class="fa fa-google"></i>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a href="https://www.pinterest.com/pin/create/button/?url=<?php the_permalink() ?>" class="nav-link yt-icon">
                                                               <i class="fa fa-pinterest-p" aria-hidden="true"></i>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                      
                                    <?php endwhile;?>
                                                   <!-- start pagination -->
                           
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination justify-content-center">
 
                                     <?php 
                                           wp_link_pages( array(
            'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'appdown' ) . '</span>',
            'after'       => '</div>',
            'link_before' => '<span>',
            'link_after'  => '</span>',
            'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'appdown' ) . ' </span>%',
            'separator'   => '<span class="screen-reader-text">, </span>',
        ) );
        ?>
                                       
                                  
                                    </ul>
               
                                </nav>
                          
                               
                                </div>
                            </div>
                        
                            <!--==== AppDown Apps ===-->
                            
                             <?php
			                $related = get_posts( array(
                                        'post_type'    =>'post',
			                            'category__in' => wp_get_post_categories($post->ID),
			                            'numberposts'  =>10,
                                        'post_status' => 'publish',
			                            'post__not_in' => array($post->ID) )
			                        );
			                 if(  $related ) { 
                             
                                ?>
                            <div class="row m0 appdown_apps wow fadeInDown">
                                <div class="row m0 headline">
                                    <h3><?php echo esc_html('Related apps','appdown');?></h3>
                                    <a href="<?php echo esc_url($cat_link ); ?>" class="base_button hover_style"><?php echo esc_html('see more','appdown')?></a>
                                </div>
                                <div class="row m0 apps_store">
                                      <?php
                                     foreach ($related as $post) {
                                    setup_postdata($post); 
                                ?>
                                    <div class="col-xl-4 col-lg-6 col-md-12 col-sm-6">
                                        <div class="media single_apps">
                                           
                                              <?php  
                                    the_post_thumbnail( 'bdt_68x68', array( 'class' => 'd-flex mr-3' ) );
                                    ?>
                                            <div class="media-body single_apps_inner">
                                                <a href="<?php the_permalink(); ?>" class="apps-title"><?php echo wp_trim_words(get_the_title(),6, ''); ?></a>
                                                <?php if(!empty($app_free)){?>
                                                <a href="<?php the_permalink(); ?>" class="base_button hover_style"><?php echo esc_html($app_free) ; ?></a>
                                                <?php }?>
                                                <div class="rating_area">
                                                    <div class="rate-container">
                                                        <?php bdt_avg_star_rating('post', $post->ID); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                      <?php
                         
                                     }
                                    
                                ?>
                                </div>
                            </div>
                                  <?php  
                        }
                            ?>
                            <!--==== Comments Area ===-->
                               <?php
                    // If comments are open or we have at least one comment, load up the comment template.
                    if ( comments_open() || get_comments_number() ) :
                        comments_template();
                    endif;
               
                ?>
         
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--========== End Appstore Area ==========-->


<?php
}
get_footer();