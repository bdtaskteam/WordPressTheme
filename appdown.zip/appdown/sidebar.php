<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Appdown
 */

$apps_version     = defined('FW') ? fw_get_db_settings_option('apps_version') : '';
$apps_short_note     = defined('FW') ? fw_get_db_settings_option('apps_short_note') : '';
$apps_logo= defined('FW') ? fw_get_db_settings_option('apps_logo') : '';
$apps_logo=isset($apps_logo ['url']) ? $apps_logo ['url'] : '';
$upload_theme_apps= defined('FW') ? fw_get_db_settings_option('upload_theme_apps') : '';
$upload_theme_apps=isset($upload_theme_apps ['url']) ? $upload_theme_apps ['url'] : '';

if(!empty($apps_logo)){
?>

<div class="row m0 download_part sidebar_inner"> 
        <img src="<?php echo esc_url($apps_logo); ?>" alt="">
        <h5><?php echo esc_html($apps_version)?></h5>
    
        <p><?php echo esc_html($apps_short_note)?> </p>
        <a  href="<?php echo esc_url($upload_theme_apps ); ?>" class="hover_style"><?php echo esc_html('DOWNLOAD APPDOWN','appdown')?></a>
                             
     </div>

<?php
}

if ( ! is_active_sidebar( 'sidebar_widgets' ) ) {
    return;
} ?>
<?php if( is_active_sidebar('sidebar_widgets') ) { ?>
     <?php dynamic_sidebar('sidebar_widgets'); ?>
<?php } ?>





 