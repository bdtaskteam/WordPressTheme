 <?php 
 
 $app_free = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_free') : '';
  $app_version = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_version') : '';
  $app_requirements = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_requirements') : '';
  $app_size = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_size') : '';
  $app_author = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_author') : '';
  $get_it_on = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'get_it_on') : '';
  // category
   $cats = get_the_terms(get_the_ID(), 'category');
   $cat  = is_array($cats) ? $cats[0]->name : '';
   $cat_link  = is_array($cats) ? get_category_link($cats[0]->term_id) : '';
   
   //galary image
$tour_gallery   = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'tour_gallery'): '';
$app_short_dis   = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_short_dis'): '';
$app_short_revew   = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_short_revew'): '';
$post_dis_specifications   = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'app_short_speci'): '';
$publish_date  = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'publish_date'): '';

$upload_apps   = defined('FW') ? fw_get_db_post_option(get_the_ID(), 'upload_apps'): '';
$upload_apps  = isset($upload_apps ['url']) ? $upload_apps ['url'] : '';


$category_ad          = defined('FW') ? fw_get_db_settings_option('category_ad') : '';
$cat_ad_type          = isset($category_ad['cat_ad_type']) ? $category_ad['cat_ad_type'] : '';
$category_ad_image    = isset($category_ad['cat_ad_image']['cat_ad_image']['url']) ? $category_ad['cat_ad_image']['cat_ad_image']['url'] :  get_template_directory_uri(). '/assets/images/add01.jpg';
$category_ad_link     = isset($category_ad['cat_ad_image']['cat_ad_link']) ? $category_ad['cat_ad_image']['cat_ad_link'] : '#';
$category_ad_code     = isset($category_ad['cat_ad_code']['cat_ad_code']) ? $category_ad['cat_ad_code']['cat_ad_code'] : '';
?>


<section class="appstore_area">
            <div class="container">
                <div class="row appstore_inner container_section">
                    <div class="col-md-4">
                        <div id="sidebar">
                            <!--========== Download Part ==========-->
                              <?php get_sidebar(); ?>
                            <!-- ========== End Quick Apps ========== -->
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div id="content">
                            <div class="row m0 chat_apps">
                                <div class="col-lg-4">
                                    <div class="row">
                                    	 <?php  
                                            the_post_thumbnail( 'bdt_165x165');
                                            ?>
                                    </div>
                                </div>
                                <div class="col-lg-8">
                                    <div class="row chat_apps_details">
                                        <h2><?php the_title();?></h2>
                                        <h4><?php echo esc_html('Latest Version :','appdown')?> <?php echo esc_html($app_version);?></h4>
                                        <div class="rating_area">
                                            <div class="rate-container">
                                                <?php bdt_avg_star_rating('post', $post->ID); ?>
                                            </div>
                                        </div>
                                        <ul class="nav download_button">
                                            <li class="nav-item">
                                                <a href="<?php echo esc_url($upload_apps); ?>" class="nav-link free_btn hover_style" download>
                                                    <span><?php echo esc_html('Free Download','appdown')?></span>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="<?php echo esc_url($upload_apps); ?>" class="nav-link purchase_btn" download>
                                                    <span><?php echo esc_html('Purches Now','appdown')?></span>
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </li>
                                        </ul>
                                        <p class="date_publish"><?php echo esc_html('Publish Date:','appdown') . esc_html($publish_date);?> 
                                        </p>
                                        <p class="requirements_version"><?php echo esc_html('Requirements:','appdown')?> <?php echo esc_html($app_requirements);?> 
                                        </p>
                                        <p class="file_size"><?php echo esc_html('Size :','appdown');?> <?php echo esc_html( $app_size );?>
                                        </p>
                                        <p class="author"><?php echo esc_html('Author:','appdown');?> <?php echo esc_html($app_author); ?></p>
                                        <p class="source"><?php echo esc_html('Get it on:','appdown');?><?php echo esc_html($get_it_on); ?>
                                        </p>
                                        <p class="file">
                                            <?php echo esc_html('Category :','appdown');?> 
                                        	<a href="<?php echo esc_url($cat_link);?>"><?php echo esc_html($cat );?>
                                            </a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="row users_rating mtb-20">
                                <div class="col-lg-6">
                                    <div class="row editors_rating">
                                        <h5><?php echo esc_html('Average editors rating','appdown');?></h5>
                                        <div class="rating_area">
                                            <div class="rate-container">
                                             
                                               <?php bdt_avg_star_rating('post', $post->ID); ?>
                                            </div>
                                        </div>
                                        <p><?php echo esc_html('Very Good','appdown');?></p>
                                    </div>
                                </div>
                                 <div class="col-lg-4">
                                    <div class="row m0">
                                        <a href="<?php echo $upload_apps; ?>" class="hover_style download_btn" download>
                                            <span><?php echo esc_html('Free Download','appdown');?></span>
                                            <i class="fa fa-download"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                              <!-- start pagination -->
                            <div class="row m0 pagination_part">
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination justify-content-center">
 
                                    <div class="text-center">
                                    <?php 
                                        $pagination = get_the_posts_pagination(array(
                                            'mid_size'  => 2,
                                            'prev_text' => '<i class="fa fa-chevron-left"></i><span class="span_link">'.esc_html__('Previous', 'appdown').'</span>',
                                            'next_text' => '<span class="span_link_right">'.esc_html__('Next', 'appdown') .'</span><i class="fa fa-chevron-right"></i>',
                                            'screen_reader_text' => ' ',
                                        ) );
                                        echo $pagination;
                                    ?>
                                    </div>

                                    </ul>
               
                                </nav>
                            </div>
                            <!-- end pagination -->
                            <div class="row perfect_cond apps_review">
                                <!-- Nav tabs -->
                                <ul class="nav nav-pills nav-justified" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" data-toggle="tab" href="#description" role="tab"><?php echo esc_html('Description')?></a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#reviews" role="tab"><?php echo esc_html('Reviews','appdown');?></a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#tags" role="tab"><?php echo esc_html('Tags','appdown');?></a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="tab" href="#specifications" role="tab"><?php echo esc_html('Specifications','appdown')?></a>
                                    </li>
                                </ul>

                                <!-- Tab panes -->
                                <div class="tab-content">
                                    <div class="tab-pane active" id="description" role="tabpanel">
                                        <h3><?php the_title(); ?></h3>
                                        
                                       <?php echo $app_short_dis;?>
                                        
                                       

                                    </div>
                                    <div class="tab-pane" id="reviews" role="tabpanel">
                                   
                                          <?php echo $app_short_revew;?>
                                    </div>
                                    <div class="tab-pane" id="tags" role="tabpanel">
									 <?php if(has_tag()) : ?>
									    <?php
									    $tags = get_the_tags(get_the_ID());
									      foreach($tags as $tag){
									        echo '<a href="'.get_tag_link($tag->term_id).'" rel="tag" class="nav hover_style">'.$tag->name.'</a>';
									    } ?>
									<?php endif; ?>
                                    </div>
                                    <div class="tab-pane" id="specifications" role="tabpanel">
                                       
                                      <?php echo $post_dis_specifications;?>
                                    </div>
                                </div>
                            </div>
                            
               
                     <?php  if($cat_ad_type=='cat_ad_image') { ?>
                            <div class="row perfect_cond apps_ad">
                              <a href="<?php echo esc_url($category_ad_link); ?>">
                            <img src="<?php echo esc_url($category_ad_image); ?>" alt="image">
                        </a>
                               
                            </div>
                              <?php
                     } elseif($cat_ad_type=='cat_ad_code') {
                    echo wp_kses_post($category_ad_code);
                    echo '<br>';
                   }   ?>
                            <!--==== AppDown Apps ===-->
                            <div class="row m0 onecol_slider">
                                <div class="owl-carousel">
		                         <?php
		                        if(is_array($tour_gallery)) {
		                            foreach($tour_gallery as $gallery_item) {
		                                $img = $gallery_item['attachment_id'];
		                                $img = wp_get_attachment_image_src($img, 'bdt_750x420');
		                                echo '<div class="item"><img src="'.esc_url($img[0]).'"  alt=""></div>';
		                            }
		                        }
		                        ?>
                                </div>
                            </div>
                            <!--==== AppDown Apps ===-->
			                <?php
			                $related = get_posts( array(
                                        'post_type'    =>'post',
			                            'category__in' => wp_get_post_categories($post->ID),
			                            'numberposts'  =>10,
                                        'post_status' => 'publish',
			                            'post__not_in' => array($post->ID) )
			                        );
			                 if(  $related ) { 
                             
                                ?>
                            <div class="row appdown_apps wow fadeInDown">
                                <div class="row m0 headline">
                                    <h3><?php echo esc_html('Related apps','appdown')?></h3>
                                    <?php 
                                    $app_cat_id=get_the_category($post->ID);//$post->ID
                                    $cat= get_category_link( $app_cat_id);
                                    ?>
                                  <a href="<?php echo esc_url($cat_link ); ?>" class="base_button hover_style"><?php echo esc_html('see more','appdown');?></a>
                                </div>
                                <div class="row m0 apps_store">
                                <?php
                                foreach ($related as $post) {
                                    setup_postdata($post); 
                                ?>
                                    <div class="col-xl-4 col-lg-6 col-md-12 col-sm-6">
                                        <div class="media single_apps">
                                    <?php  
                                    the_post_thumbnail( 'bdt_68x68', array( 'class' => 'd-flex mr-3' ) );
                                    ?>
                                            <div class="media-body single_apps_inner">
                                                <a href="<?php the_permalink(); ?>" class="apps-title"><?php echo wp_trim_words(get_the_title(),6, ''); ?></a>
                                                <a href="#" class="base_button hover_style"><?php echo esc_html($app_free); ?></a>
                                                <div class="rating_area">
                                                    <div class="rate-container">
                                                        <?php bdt_avg_star_rating('post', $post->ID); ?>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                           
                                  <?php
                         
                                     }
                                    
                                ?>
                                
                                </div>
                            </div>
                            <?php  
                        }
                            ?>
                     <?php
                       	while ( have_posts() ) : the_post();
                        if ( comments_open() || get_comments_number() ) {
                            comments_template();
                        }
	endwhile;
                    ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--========== End Appstore Area ==========-->