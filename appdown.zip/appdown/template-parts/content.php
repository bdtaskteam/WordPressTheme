<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Appdown
 */
$read_more = defined('FW') ? fw_get_db_settings_option('blog_read_more') : esc_html__('Details','appdown');
$blog_excerpt = defined('FW') ? fw_get_db_settings_option('blog_excerpt') : 30;
?>


    <div <?php post_class('blog_page'); ?>  id="post-<?php the_ID(); ?>" >
     
    <?php the_post_thumbnail( 'bdt_750x369', array('class'=>'img-responsive'), true ); ?>
        <div class="content_area">
            <a href="<?php the_permalink(); ?>" class="post_heading"><?php the_title(); ?></a>
            <ul class="nav post_author">

                <li class="nav-item"><?php esc_html_e('By :', 'appdown'); ?>
                <a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' )); ?>">
                <span> 
                  <?php echo get_the_author_meta('display_name'); ?> </span>
                </a></li>
                <li class="nav-item">Date : <?php the_time('M d, Y'); ?></li>  

            </ul>
            <p class="text-justify"> <?php echo wp_trim_words(get_the_content(), $blog_excerpt, ''); ?></p>
           
            <a href="<?php the_permalink(); ?>" class="base_button hover_style"><?php echo $read_more; ?></a>
       
        </div>
    </div>